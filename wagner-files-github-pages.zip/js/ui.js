import { html, raw, esc } from './lib/html.js';
import { db, countryName } from './data.js';

export const INSUFFICIENT = 'Insufficient verified information.';
export const empty = () => html`<p class="empty">${INSUFFICIENT}</p>`;
export const isEmpty = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '') || (Array.isArray(v) && v.length === 0);

export const CONF = {
  confirmed: { label: 'CONFIRMED', short: 'Confirmed', desc: 'Confirmed by an official investigation, court or sanctions finding, or exceptionally strong primary evidence.' },
  strong: { label: 'STRONGLY CORROBORATED', short: 'Strongly corroborated', desc: 'Corroborated by multiple independent sources with separate original evidence.' },
  credible: { label: 'CREDIBLY REPORTED', short: 'Credibly reported', desc: 'Reported by a reputable source but not independently established.' },
  disputed: { label: 'DISPUTED', short: 'Disputed', desc: 'Credible sources conflict, or the party denies it with some supporting evidence.' },
  unverified: { label: 'UNVERIFIED', short: 'Unverified', desc: 'Single-source, party claim only, or unconfirmed.' },
};
export const CONF_ORDER = ['confirmed', 'strong', 'credible', 'disputed', 'unverified'];
export const confRank = (c) => { const i = CONF_ORDER.indexOf(c); return i < 0 ? 9 : i; };

export function badge(conf) {
  const m = CONF[conf];
  if (!m) return html`<span class="badge badge--ungraded" title="No valid evidence grade recorded">UNGRADED</span>`;
  return html`<span class="badge badge--${conf}" title="${m.short}: ${m.desc}">${m.label}</span>`;
}

export const STATUS = {
  'active-africa-corps': { label: 'Active — Africa Corps', desc: 'Russian MOD Africa Corps presence currently documented.' },
  'active-wagner-legacy': { label: 'Active — Wagner legacy', desc: 'Wagner-era structures or personnel reported still active.' },
  reported: { label: 'Reported presence', desc: 'Presence reported but not well established.' },
  former: { label: 'Former presence', desc: 'Documented presence that has ended.' },
  insufficient: { label: 'Insufficient information', desc: 'Listed, but evidence is too thin to characterise.' },
};
export const STATUS_ORDER = ['active-africa-corps', 'active-wagner-legacy', 'reported', 'former', 'insufficient'];
export const statusChip = (s) => html`<span class="status-chip"><span class="swatch" style="background:var(--s-${STATUS[s] ? s : 'insufficient'})" aria-hidden="true"></span>${STATUS[s]?.label || s || 'Status not recorded'}</span>`;

export const SRC_CAT = {
  un: 'United Nations', government: 'Governments', sanctions: 'Sanctions authorities', court: 'Courts & prosecutors', ngo: 'NGOs', journalism: 'Investigative journalism', academic: 'Academic & think-tank', osint: 'Satellite imagery & OSINT', 'party-statement': 'Party statements (claims, not verification)',
};
export const SRC_CAT_ORDER = Object.keys(SRC_CAT);

export const SECTION_LABEL = {
  history: 'Origins & history', ukraine: 'Operations in Ukraine', 'prison-recruitment': 'Prison recruitment', casualties: 'Casualty estimates', rebellion: 'The June 2023 rebellion', 'prigozhin-crash': 'The August 2023 crash', transition: 'From Wagner to Africa Corps', money: 'Follow the money', 'sanctions-evasion': 'Sanctions evasion', infoops: 'Information operations', accountability: 'Accountability', 'executive-summary': 'Executive summary', 'methodology-notes': 'Methodology notes',
};
export const TL_CAT_LABEL = { origins: 'Origins', ukraine: 'Ukraine', syria: 'Syria', africa: 'Africa', rebellion: 'Rebellion', restructuring: 'Restructuring', sanctions: 'Sanctions', accountability: 'Accountability', finance: 'Finance', infoops: 'Information ops' };
export const KIND_LABEL = { person: 'Person', organization: 'Organization', company: 'Company', 'state-body': 'State body', 'armed-group': 'Armed group', media: 'Media', government: 'Government', aircraft: 'Aircraft', vessel: 'Vessel' };
export const REL_LABEL = { controls: 'controls', owns: 'owns', funds: 'funds', commands: 'commands', 'contracts-with': 'contracts with', 'successor-of': 'successor of', 'subsidiary-of': 'subsidiary of', 'linked-to': 'linked to', supplies: 'supplies', 'operates-in': 'operates in', employs: 'employs', founded: 'founded' };

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function fmtDate(d) {
  if (!d || typeof d !== 'string') return '';
  const m = d.match(/^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?$/);
  if (!m) return d;
  if (m[3]) return `${+m[3]} ${MONTHS[+m[2] - 1]} ${m[1]}`;
  if (m[2]) return `${MONTHS[+m[2] - 1]} ${m[1]}`;
  return m[1];
}
export const fmtRange = (a, b) => (b ? `${fmtDate(a)} – ${fmtDate(b)}` : fmtDate(a));

// ---------- citations (per rendered page) ----------
let registry = null;
export function startCitations() { registry = { order: [], map: new Map() }; }
export function citeNum(id) {
  if (!registry) startCitations();
  if (!registry.map.has(id)) { registry.order.push(id); registry.map.set(id, registry.order.length); }
  return registry.map.get(id);
}
export function cites(ids) {
  if (!Array.isArray(ids) || ids.length === 0) return '';
  return html`<span class="cites">${ids.map((id) => {
    const s = db.sourceById.get(id);
    const n = citeNum(id);
    if (!s) return html`<button type="button" class="cite broken" data-src="${id}" aria-label="Source ${n}: missing reference ${id}" title="Missing source reference: ${id}">[${n}?]</button>`;
    return html`<button type="button" class="cite" data-src="${id}" aria-label="Source ${n}: ${s.title}" title="${s.title} — ${s.publisher || ''}">[${n}]</button>`;
  })}</span>`;
}
export function endnotes() {
  if (!registry || registry.order.length === 0) return '';
  return html`<section class="endnotes container" aria-labelledby="endnotes-h"><h2 id="endnotes-h" class="h3">Sources cited on this page</h2><ol>${registry.order.map((id) => {
    const s = db.sourceById.get(id);
    if (!s) return html`<li><span class="mono">${id}</span> — missing source record</li>`;
    return html`<li><a href="#/source/${encodeURIComponent(id)}">${s.title}</a> <span class="pub">— ${s.publisher || ''}${s.date ? ', ' + fmtDate(s.date) : ''}</span></li>`;
  })}</ol></section>`;
}

// ---------- claims ----------
export function claimItem(c) {
  if (!c || typeof c !== 'object') return '';
  return html`<li class="claim"><div class="claim-badge">${badge(c.confidence)}</div><div class="claim-text">${c.text || ''} ${cites(c.source_ids)}${c.note ? html`<span class="claim-note">Note: ${c.note}</span>` : ''}</div></li>`;
}
export function claimList(list) {
  const arr = Array.isArray(list) ? list.filter(Boolean) : list && typeof list === 'object' ? [list] : [];
  if (!arr.length) return empty();
  return html`<ul class="claims">${arr.map(claimItem)}</ul>`;
}

// ---------- links ----------
export const entityLink = (id) => {
  const e = db.entityById.get(id);
  return e ? html`<a href="#/entity/${encodeURIComponent(id)}">${e.name}</a>` : html`<span class="mono" title="Referenced entity not found in data">${id} (missing)</span>`;
};
export const countryLink = (iso) => (db.countryByIso.has(iso) ? html`<a href="#/country/${iso}">${countryName(iso)}</a>` : html`${countryName(iso)}`);
export const sourceLink = (id) => { const s = db.sourceById.get(id); return s ? html`<a href="#/source/${encodeURIComponent(id)}">${s.title}</a>` : html`<span class="mono">${id} (missing)</span>`; };
export const reportLink = (id) => html`<a class="report-link" href="#/corrections?item=${encodeURIComponent(id)}">Report an error</a>`;
export const inlineList = (items) => (items.length ? html`<ul class="inline-list">${items.map((i) => html`<li>${i}</li>`)}</ul>` : empty());

export function incidentTitle(inc) {
  const t = inc.title || 'Untitled incident';
  if (inc.confidence === 'confirmed' || /^alleged\b/i.test(t)) return t;
  return `Alleged: ${t}`;
}

export function field(label, content) {
  const c = isEmpty(content) || content === '' ? empty() : content;
  return html`<dt>${label}</dt><dd>${c}</dd>`;
}

export function legend({ compact = false } = {}) {
  return html`<div class="legend ${compact ? 'legend-compact' : ''}" role="group" aria-label="Evidence grading legend"><span class="legend-title">Evidence grades</span>${CONF_ORDER.map((c) => html`<span class="item">${badge(c)}${compact ? '' : html`<span>${CONF[c].desc}</span>`}</span>`)}</div>`;
}
export function statusLegend() {
  return html`<div class="legend legend-compact" role="group" aria-label="Country status legend"><span class="legend-title">Country status</span>${STATUS_ORDER.map((s) => html`<span class="item" title="${STATUS[s].desc}"><span class="swatch" style="background:var(--s-${s})" aria-hidden="true"></span>${STATUS[s].label}</span>`)}<span class="item"><span class="swatch" style="background:var(--s-none)" aria-hidden="true"></span>Not in database</span></div>`;
}

export function pageHead({ kicker, title, lede, meta, alleged = false }) {
  return html`<header class="page-head"><p class="kicker ${alleged ? 'alleged' : ''}">${kicker || ''}</p><h1 id="page-title" tabindex="-1">${title}</h1>${lede ? html`<p class="lede">${lede}</p>` : ''}${meta ? html`<div class="meta-line">${meta}</div>` : ''}</header>`;
}

// page blocks (claims or table)
const hN = (level, text, cls = '') => raw(`<h${level}${cls ? ` class="${cls}"` : ''}>${esc(text)}</h${level}>`);
export function renderBlocks(page, { headingLevel = 3 } = {}) {
  const blocks = Array.isArray(page.blocks) ? page.blocks : [];
  if (!blocks.length) return empty();
  return blocks.map((b) => {
    if (!b || typeof b !== 'object') return '';
    const parts = [b.heading ? hN(headingLevel, b.heading) : ''];
    if (b.claims !== undefined) parts.push(claimList(b.claims));
    if (b.table) parts.push(dataTable(b.table));
    return html`<div class="block">${parts}</div>`;
  });
}
export function dataTable(t) {
  const cols = Array.isArray(t.columns) ? t.columns : [];
  const rows = Array.isArray(t.rows) ? t.rows : [];
  if (!rows.length) return empty();
  return html`<div class="table-wrap cards"><table class="data responsive"><caption>Sources for this table: ${isEmpty(t.source_ids) ? 'none recorded' : cites(t.source_ids)}</caption><thead><tr>${cols.map((c) => html`<th scope="col">${c}</th>`)}</tr></thead><tbody>${rows.map((r) => html`<tr>${(Array.isArray(r) ? r : []).map((cell, i) => html`<td data-label="${cols[i] || ''}">${isEmpty(cell) ? html`<span class="empty">${INSUFFICIENT}</span>` : String(cell)}</td>`)}</tr>`)}</tbody></table></div>`;
}
export function renderPages(pages, { idPrefix = 'sec', level = 3 } = {}) {
  if (!pages.length) return empty();
  return pages.map((p) => html`<article class="page-article" id="${idPrefix}-${p.id}">${hN(level, p.title || '', 'h-article')}${renderBlocks(p, { headingLevel: Math.min(level + 1, 6) })}<p>${reportLink(p.id)}</p></article>`);
}

// ---------- misc ----------
export function download(filename, text, mime = 'application/json') {
  const blob = new Blob([text], { type: mime + ';charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
export function toCSV(rows, columns) {
  const q = (v) => { const s = Array.isArray(v) ? v.join('; ') : v == null ? '' : String(v); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return [columns.map((c) => q(c.label)).join(','), ...rows.map((r) => columns.map((c) => q(c.get(r))).join(','))].join('\r\n');
}
export const debounce = (fn, ms = 150) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export function setQuery(path, params) {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== '' && v != null && !(Array.isArray(v) && !v.length)) q.set(k, Array.isArray(v) ? v.join(',') : v);
  const s = q.toString();
  history.replaceState(null, '', `${location.pathname}${location.search}#/${path}${s ? '?' + s : ''}`);
}
export function announce(msg) { const a = document.getElementById('announcer'); if (a) { a.textContent = ''; setTimeout(() => { a.textContent = msg; }, 30); } }
export const options = (list, selected, allLabel) => html`<option value="">${allLabel}</option>${list.map(([v, l]) => html`<option value="${v}" ${String(v) === String(selected) ? raw('selected') : ''}>${l}</option>`)}`;
export const uniq = (a) => [...new Set(a)];
export const plural = (n, s, p = s + 's') => `${n.toLocaleString('en-US')} ${n === 1 ? s : p}`;
export { html, raw, esc };
