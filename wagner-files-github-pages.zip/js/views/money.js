import { html, raw, renderPages, claimItem, claimList, SECTION_LABEL, empty, legend, plural, entityLink, badge, KIND_LABEL, CONF_ORDER } from '../ui.js';
import { relationshipTable } from '../components.js';
import { pagesFor, countryName } from '../data.js';

const SECTORS = [
  ['gold', 'Gold', /\bgold/i], ['diamonds', 'Diamonds', /diamond/i], ['oil-gas', 'Oil & gas', /\boil\b|\bgas\b|petrol|fuel|refin/i],
  ['mining', 'Mining', /mining|\bmines?\b|mineral|uranium|lithium|manganese|cobalt/i], ['timber', 'Timber', /timber|forest|\bwood|logging/i],
  ['security', 'Security contracts', /security (contract|service|compan)|protection|guard|training contract|military contract/i], ['concessions', 'Concessions', /concession|licen[cs]e|permit|exploration right/i],
  ['trading', 'Trading', /\btrad(e|es|ing)\b|export|import|smuggl|beer|vodka|sugar|grain/i], ['logistics', 'Logistics', /logistic|aviation|airline|flight|aircraft|shipping|vessel|transport|cargo|airport/i],
  ['corporate', 'Corporate structures', /corporate|holding|subsidiar|front compan|shell compan|beneficial owner|registered|ownership/i], ['evasion', 'Sanctions evasion', /sanction|evasion|evade|circumvent/i],
];
const OWNERSHIP = ['owns', 'subsidiary-of', 'controls', 'funds'];
let graph = null, db, sectorData;

export function render(ctx) {
  db = ctx.db;
  const money = pagesFor('money');
  const evasion = pagesFor('sanctions-evasion');
  const pageClaims = [...money, ...evasion].flatMap((p) => (p.blocks || []).flatMap((b) => (b?.claims || []).map((c) => ({ c, heading: b.heading || '', page: p }))));
  const countryClaims = db.countries.flatMap((co) => (co.economic_interests || []).map((c) => ({ c, country: co })));
  const companies = db.entities.filter((e) => ['company', 'organization'].includes(e.kind));
  sectorData = SECTORS.map(([id, label, re]) => {
    const pc = pageClaims.filter((x) => re.test(x.heading) || re.test(x.c.text || ''));
    const cc = countryClaims.filter((x) => re.test(x.c.text || ''));
    const co = companies.filter((e) => re.test(`${e.name} ${e.role || ''} ${e.summary || ''}`));
    const ev = id === 'evasion' ? evasion : [];
    return { id, label, pc, cc, co, ev, n: pc.length + cc.length + co.length };
  });
  const own = db.relationships.filter((r) => OWNERSHIP.includes(r.type));
  const sel = ctx.query.get('sector') || '';
  return {
    title: 'Follow the money',
    html: html`
    <header class="page-head"><p class="kicker">Follow the money</p><h1 id="page-title" tabindex="-1">Follow the money</h1>
    <p class="lede">Gold, diamonds, oil and gas, mining, timber, security contracts, concessions, trading, logistics, corporate structures and sanctions evasion. Financial links are graded like every other claim; ownership and control edges are shown as a separate network.</p></header>
    ${legend({ compact: true })}
    <section class="section" aria-labelledby="h-sectors"><h2 id="h-sectors">By sector</h2>
      <p class="help">Sector groupings are keyword-based navigation aids across the money sections, country economic-interest claims and company profiles — not formal classifications.</p>
      <div class="grid grid-4" role="group" aria-label="Sectors">${sectorData.map((s) => html`<button type="button" class="card sector-card" data-sector="${s.id}" aria-pressed="${s.id === sel}" aria-controls="sector-detail"><h3>${s.label}</h3><span class="card-meta">${s.n ? `${plural(s.pc.length + s.cc.length, 'claim')} · ${plural(s.co.length, 'company', 'companies')}` : 'Insufficient verified information.'}</span></button>`)}</div>
      <div id="sector-detail" aria-live="polite"></div>
    </section>
    <section class="section" aria-labelledby="h-money"><h2 id="h-money">${SECTION_LABEL.money}</h2>${renderPages(money, { idPrefix: 'm' })}</section>
    <section class="section" aria-labelledby="h-own"><h2 id="h-own">Ownership &amp; control network</h2>
      <p class="help">Only <em>owns</em>, <em>subsidiary of</em>, <em>controls</em> and <em>funds</em> relationships. Select a node or line for evidence. The table below the graph lists the same relationships.</p>
      ${own.length ? html`<div id="own-graph" class="graph-wrap small"></div>` : ''}
      <div style="margin-top:1rem">${relationshipTable(own, { caption: 'Ownership, control and funding relationships' })}</div></section>
    <section class="section" aria-labelledby="h-ev"><h2 id="h-ev">${SECTION_LABEL['sanctions-evasion']}</h2>${renderPages(evasion, { idPrefix: 'ev' })}</section>
    <section class="section" aria-labelledby="h-co"><h2 id="h-co">Companies &amp; corporate entities</h2>
      ${companies.length ? html`<div class="table-wrap cards"><table class="data responsive"><caption>Companies and organizations profiled (${companies.length})</caption><thead><tr><th scope="col">Name</th><th scope="col">Role</th><th scope="col">Countries</th><th scope="col">Designations</th></tr></thead><tbody>${companies.map((e) => html`<tr><td data-label="Name">${entityLink(e.id)}</td><td data-label="Role">${e.role || '—'}</td><td data-label="Countries">${(e.countries || []).map(countryName).join(', ') || '—'}</td><td data-label="Designations" class="mono">${(db.sanctionsByEntity.get(e.id) || []).length}</td></tr>`)}</tbody></table></div>` : empty()}</section>`,
  };
}

function showSector(root, id) {
  const s = sectorData.find((x) => x.id === id);
  root.querySelectorAll('[data-sector]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.sector === id)));
  const box = root.querySelector('#sector-detail');
  if (!s) { box.innerHTML = ''; return; }
  box.innerHTML = String(html`<div class="card" style="margin-top:1rem"><h3>${s.label}</h3>
    ${s.n === 0 && !s.ev.length ? empty() : html`
    <h4>From the money and sanctions-evasion sections</h4>${s.pc.length ? html`<ul class="claims">${s.pc.map((x) => claimItem(x.c))}</ul>` : empty()}
    <h4>From country profiles (economic interests)</h4>${s.cc.length ? html`<ul class="claims">${s.cc.map((x) => html`${claimItem(x.c)}`)}</ul><p class="help">Countries: ${[...new Set(s.cc.map((x) => x.country))].map((c, i) => html`${i ? ', ' : ''}<a href="#/country/${c.iso3}">${c.name}</a>`)}</p>` : empty()}
    <h4>Companies</h4>${s.co.length ? html`<ul>${s.co.map((e) => html`<li>${entityLink(e.id)}${e.role ? html` <span class="card-meta">— ${e.role}</span>` : ''}</li>`)}</ul>` : empty()}`}</div>`);
  import('../app.js').then((m) => m.refreshEndnotes());
}

export async function mount(root, ctx) {
  root.querySelectorAll('[data-sector]').forEach((b) => b.addEventListener('click', () => {
    const on = b.getAttribute('aria-pressed') !== 'true';
    const id = on ? b.dataset.sector : '';
    history.replaceState(null, '', `${location.pathname}${location.search}#/money${id ? '?sector=' + id : ''}`);
    showSector(root, id);
  }));
  const sel = ctx.query.get('sector');
  if (sel) showSector(root, sel);
  const el = root.querySelector('#own-graph');
  if (!el) return;
  const own = db.relationships.filter((r) => OWNERSHIP.includes(r.type) && db.entityById.has(r.from) && db.entityById.has(r.to));
  const ids = [...new Set(own.flatMap((r) => [r.from, r.to]))];
  const { createGraph } = await import('../graphkit.js');
  const { openNodePanel, openEdgePanel } = await import('../netpanels.js');
  const nm = (id) => db.entityById.get(id)?.name || id;
  graph = await createGraph(el, {
    nodes: ids.map((id) => { const e = db.entityById.get(id); return { id, name: e.name, kind: e.kind, kindLabel: KIND_LABEL[e.kind] || e.kind, tier: db.entityTiers[id] ?? 4 }; }),
    links: own.map((r) => ({ id: r.id, source: r.from, target: r.to, type: r.type, confidence: r.confidence, sourceName: nm(r.from), targetName: nm(r.to) })),
    tiers: db.tiers,
    onNode: (id) => { graph.focus(id); openNodePanel(id); }, onEdge: (id) => openEdgePanel(id),
  });
}
export function unmount() { graph?.destroy(); graph = null; }
