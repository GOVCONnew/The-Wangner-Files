import { html, renderPages, legend, fmtDate } from '../ui.js';
import { pagesFor } from '../data.js';

export function render({ db }) {
  const pages = pagesFor('executive-summary');
  return {
    title: 'Executive summary',
    html: html`<header class="page-head"><p class="kicker">Executive summary</p><h1 id="page-title" tabindex="-1">Executive summary</h1>
    <p class="lede">The investigation in brief. Every statement below carries its evidence grade and sources; select a bracketed number to see the source.</p>
    <div class="meta-line"><span>Last updated ${fmtDate(db.meta.last_updated)}</span></div></header>
    ${legend({ compact: true })}
    <div class="section">${renderPages(pages, { idPrefix: 'es', level: 2 })}</div>
    <p class="principle">Absence from this database does not imply innocence or guilt.</p>
    <p><a href="#/findings">The 25 best-documented findings →</a> · <a href="#/methodology">Methodology →</a></p>`,
  };
}
