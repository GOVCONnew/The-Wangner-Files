import { html, renderPages, SECTION_LABEL, legend } from '../ui.js';
import { pagesFor } from '../data.js';

export function render({ params }) {
  const s = params[0];
  if (!SECTION_LABEL[s]) return null;
  const pages = pagesFor(s);
  return {
    title: SECTION_LABEL[s],
    html: html`<header class="page-head"><p class="kicker">Investigation section</p><h1 id="page-title" tabindex="-1">${SECTION_LABEL[s]}</h1></header>
    ${legend({ compact: true })}<div style="margin-top:1rem" class="section">${renderPages(pages, { idPrefix: 's', level: 2 })}</div>`,
  };
}
