import { html, claimList, entityLink, countryLink, reportLink, empty, KIND_LABEL, field, cites, plural, isEmpty } from '../ui.js';
import { incidentTable, sanctionsTable, relationshipTable, sourceIdsOf, sourceListing, correctionsFor } from '../components.js';

export function render({ db, params }) {
  const e = db.entityById.get(params[0]);
  if (!e) return null;
  const rels = db.relsByEntity.get(e.id) || [];
  const sanctions = db.sanctionsByEntity.get(e.id) || [];
  const related = (db.sanctionsByRelatedOrg.get(e.id) || []).filter((s) => s.target_entity !== e.id);
  const incidents = db.incidentsByEntity.get(e.id) || [];
  const members = db.membersByOrg.get(e.id) || [];
  const tier = db.tiers.find((t) => t.id === db.entityTiers[e.id]);
  const srcs = sourceIdsOf({ source_ids: e.source_ids, activities: e.activities });
  const corrections = db.correctionsByItem.get(e.id) || [];
  return {
    title: e.name,
    html: html`
    <p><a class="back-link" href="#/people">← People &amp; organizations</a></p>
    <header class="page-head"><p class="kicker">${KIND_LABEL[e.kind] || e.kind || 'Profile'}${tier ? ` · network tier: ${tier.label}` : ''}</p><h1 id="page-title" tabindex="-1">${e.name}</h1>
    ${e.summary ? html`<p class="lede">${e.summary} ${cites(e.source_ids)}</p>` : ''}
    <div class="meta-line"><span>${plural(rels.length, 'relationship')}</span><span>${plural(sanctions.length, 'designation')}</span><span>${plural(incidents.length, 'linked incident')}</span><span class="id-line">${e.id}</span>${reportLink(e.id)} <a href="#/network?focus=${encodeURIComponent(e.id)}">Show in network →</a></div></header>
    <dl class="fields">
      ${field('Aliases', (e.aliases || []).length ? e.aliases.join('; ') : '')}
      ${field('Role', e.role)}
      ${field('Organizations', (e.organizations || []).length ? e.organizations.map((o, i) => html`${i ? ', ' : ''}${entityLink(o)}`) : '')}
      ${field('Period', e.period)}
      ${field('Countries', (e.countries || []).length ? e.countries.map((c, i) => html`${i ? ', ' : ''}${countryLink(c)}`) : '')}
      ${e.status ? field('Status', e.status) : ''}
      ${members.length ? field('Linked people & units', members.map((m, i) => html`${i ? ', ' : ''}${entityLink(m.id)}`)) : ''}
    </dl>
    <section class="section" aria-labelledby="h-act"><h2 id="h-act">Documented activities</h2>${claimList(e.activities)}</section>
    <section class="section" aria-labelledby="h-san"><h2 id="h-san">Sanctions</h2>${sanctionsTable(sanctions, { caption: `Designations of ${e.name}` })}
      ${related.length ? html`<h3>Designations naming ${e.name} as a related organization</h3>${sanctionsTable(related, { caption: 'Related designations' })}` : ''}</section>
    <section class="section" aria-labelledby="h-rel"><h2 id="h-rel">Relationships</h2>${relationshipTable(rels, { perspective: e.id, caption: `Relationships of ${e.name}` })}</section>
    <section class="section" aria-labelledby="h-inc"><h2 id="h-inc">Incidents in which this entity is alleged to be responsible</h2>${incidentTable(incidents, { caption: 'Linked incidents', limit: 50 })}</section>
    ${correctionsFor(e.id)}
    <section class="section" aria-labelledby="h-src"><h2 id="h-src">Sources</h2>${sourceListing(srcs)}</section>`,
  };
}
