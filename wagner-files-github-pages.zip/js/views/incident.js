import { html, badge, fmtRange, entityLink, countryLink, incidentTitle, field, cites, reportLink, CONF, isEmpty } from '../ui.js';
import { sourceListing, correctionsFor } from '../components.js';
import { countryName } from '../data.js';

export function render({ db, params }) {
  const i = db.incidentById.get(params[0]);
  if (!i) return null;
  const confirmed = i.confidence === 'confirmed';
  const txt = (v) => (isEmpty(v) ? '' : html`${v}`);
  const corrections = db.correctionsByItem.get(i.id) || [];
  return {
    title: incidentTitle(i),
    html: html`
    <p><a class="back-link" href="#/incidents">← Incident database</a></p>
    <header class="page-head"><p class="kicker ${confirmed ? '' : 'alleged'}">${confirmed ? 'Documented incident' : 'Allegation — not established as confirmed fact'}</p>
    <h1 id="page-title" tabindex="-1">${incidentTitle(i)}</h1>
    <div class="meta-line">${badge(i.confidence)}<span>${fmtRange(i.date, i.date_end)}</span><span>${i.location ? i.location + ', ' : ''}${countryName(i.country)}</span><span class="id-line">${i.id}</span>${reportLink(i.id)}</div></header>
    ${!confirmed ? html`<p class="note-box">Evidence grade: <strong>${CONF[i.confidence]?.short || 'ungraded'}</strong>. ${CONF[i.confidence]?.desc || ''} This entry records an allegation and the evidence for it; it is not a finding of responsibility.</p>` : ''}
    <dl class="fields">
      ${field('Date', fmtRange(i.date, i.date_end))}
      ${field('Country', i.country ? countryLink(i.country) : '')}
      ${field('Location', i.location ? html`${i.location}${typeof i.lat === 'number' && typeof i.lon === 'number' ? html` <span class="mono" style="color:var(--muted)">(${i.lat}, ${i.lon})</span>` : ''}` : '')}
      ${field('Incident type', (i.types || []).length ? (i.types || []).map((t) => html`<span class="tag">${t}</span>`) : '')}
      ${field('Description', txt(i.description))}
      ${field(confirmed ? 'Responsible entity' : 'Alleged responsible entity', (i.alleged_entities || []).length ? i.alleged_entities.map((e, k) => html`${k ? ', ' : ''}${entityLink(e)}`) : '')}
      ${field('Victims', txt(i.victims))}
      ${field('Evidence', txt(i.evidence))}
      ${field('Attribution basis', txt(i.attribution_basis))}
      ${field('Independent corroboration', txt(i.independent_corroboration))}
      ${field('Investigation', txt(i.investigation))}
      ${field('Legal status', txt(i.legal_status))}
      ${field('Confidence', html`${badge(i.confidence)} <span style="font-family:var(--sans);font-size:.88rem;color:var(--text-2)">${CONF[i.confidence]?.desc || ''}</span>`)}
      ${field('Sources', (i.source_ids || []).length ? cites(i.source_ids) : '')}
    </dl>
    ${correctionsFor(i.id, { heading: 'Corrections to this entry' })}
    <section class="section" aria-labelledby="h-src"><h2 id="h-src">Source documents</h2>${sourceListing(i.source_ids || [])}</section>`,
  };
}
