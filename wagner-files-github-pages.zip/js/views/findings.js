import { html, badge, cites, empty, legend, reportLink } from '../ui.js';

const STATUS = { disputed: 'Disputed', 'single-source': 'Single source', contradictory: 'Contradictory evidence', 'no-evidence': 'No supporting evidence' };
export function render({ db }) {
  const f = db.findings;
  return {
    title: 'Findings',
    html: html`
    <header class="page-head"><p class="kicker">Findings</p><h1 id="page-title" tabindex="-1">The 25 best-documented findings</h1>
    <p class="lede">Selected on the strength of the evidence and the significance of the conduct, not on shock value. Each lists its primary sources and independent corroboration.</p></header>
    ${legend({ compact: true })}
    <section class="section" aria-labelledby="h-best"><h2 id="h-best" class="visually-hidden">Best-documented findings</h2>
    ${f.length ? html`<ol class="finding-list">${f.map((x) => html`<li class="finding" id="finding-${x.rank}"><span class="rank" aria-hidden="true">${String(x.rank ?? '').padStart(2, '0')}</span><div>
      <p class="ftext"><span class="visually-hidden">Finding ${x.rank}: </span>${x.finding}</p>
      <div class="fmeta">${badge(x.confidence)}${x.period ? html`<span>Period: ${x.period}</span>` : ''}${x.location ? html`<span>Location: ${x.location}</span>` : ''}</div>
      ${x.evidence ? html`<p style="margin:.5rem 0 .3rem;color:var(--text-2);font-size:.92rem"><strong>Evidence:</strong> ${x.evidence}</p>` : ''}
      <div class="fmeta"><span>Primary sources: ${(x.primary_source_ids || []).length ? cites(x.primary_source_ids) : 'none recorded'}</span><span>Corroboration: ${(x.corroboration_source_ids || []).length ? cites(x.corroboration_source_ids) : 'none recorded'}</span>${reportLink(`finding-${x.rank}`)}</div>
    </div></li>`)}</ol>` : empty()}
    </section>
    <section class="section" aria-labelledby="h-unp"><h2 id="h-unp">What remains unproven</h2>
    <p class="help">Claims that circulate widely but that the evidence does not establish. Listing a claim here is not a finding that it is false.</p>
    ${db.unproven.length ? html`<div class="grid grid-2">${db.unproven.map((u) => html`<article class="card" id="${u.id}"><p class="kicker">${STATUS[u.status] || u.status || 'Status not recorded'}</p><h3 style="font-family:var(--serif);font-weight:600">${u.claim}</h3><p><strong>Why unproven:</strong> ${u.why_unproven || ''}</p><p class="card-meta">Sources: ${(u.source_ids || []).length ? cites(u.source_ids) : 'none recorded'} · ${reportLink(u.id)}</p></article>`)}</div>` : empty()}
    </section>`,
  };
}
