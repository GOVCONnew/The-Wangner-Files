import { html, statusLegend, statusChip, STATUS_ORDER, STATUS, CONF_ORDER, badge, plural, empty } from '../ui.js';
import { countryName } from '../data.js';

let inst = null;
export function render({ db }) {
  const withCoords = db.incidents.filter((i) => typeof i.lat === 'number' && typeof i.lon === 'number').length;
  const byStatus = STATUS_ORDER.map((s) => [s, db.countries.filter((c) => c.status === s).sort((a, b) => a.name.localeCompare(b.name))]);
  const other = db.countries.filter((c) => !STATUS[c.status]);
  return {
    title: 'Global map',
    html: html`
    <header class="page-head"><p class="kicker">Global map</p><h1 id="page-title" tabindex="-1">Where Wagner and the Africa Corps have been documented</h1>
    <p class="lede">Countries are shaded by the status recorded in their country profile. Select a highlighted country to open its profile. A text list of every country follows the map.</p></header>
    ${statusLegend()}
    <div class="map-controls">
      <label><input type="checkbox" id="toggle-incidents"> Show incident markers (${plural(withCoords, 'incident')} with coordinates)</label>
      <span class="legend-compact" aria-label="Incident marker colours">${CONF_ORDER.map((c) => html`<span style="margin-right:.6rem;font-size:.8rem"><span class="dot dot--${c}" aria-hidden="true"></span> ${badge(c)}</span>`)}</span>
    </div>
    <div class="map-wrap"><div id="world-map" class="map" role="region" aria-label="Interactive world map. Use the country list below for keyboard and screen-reader access."></div></div>
    <p class="help">Drag to pan, scroll or pinch to zoom. Incident markers mark approximate locations as recorded; markers are allegations unless graded CONFIRMED.</p>
    <section class="section" aria-labelledby="h-list"><h2 id="h-list">All countries in the database</h2>
    ${db.countries.length ? html`<div class="grid grid-3">${[...byStatus, ['other', other]].filter(([, l]) => l.length).map(([s, list]) => html`<div class="card"><h3>${s === 'other' ? 'Status not recognised' : STATUS[s].label} <span class="count mono" style="color:var(--muted)">(${list.length})</span></h3><ul class="src-list">${list.map((c) => html`<li style="padding:.3rem 0"><a href="#/country/${c.iso3}">${c.name}</a> <span class="card-meta">${c.region || ''} · ${plural((db.incidentsByCountry.get(c.iso3) || []).length, 'incident')}</span></li>`)}</ul></div>`)}</div>` : empty()}
    </section>`,
  };
}
export async function mount(root, { db }) {
  const { createMap } = await import('../mapkit.js');
  inst = await createMap(root.querySelector('#world-map'), { onCountry: (iso) => (location.hash = `#/country/${iso}`), incidents: db.incidents });
  root.querySelector('#toggle-incidents').addEventListener('change', (e) => inst.setIncidents(e.target.checked));
}
export function unmount() { inst?.destroy(); inst = null; }
