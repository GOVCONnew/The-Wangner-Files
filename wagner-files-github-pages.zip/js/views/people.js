import { html, options, setQuery, debounce, KIND_LABEL, uniq, empty, plural } from '../ui.js';
import { countryName } from '../data.js';

let db, state;
const GROUPS = [['person', 'People'], ['armed-group', 'Armed groups'], ['state-body', 'State bodies'], ['government', 'Governments'], ['company', 'Companies'], ['organization', 'Organizations'], ['media', 'Media'], ['aircraft', 'Aircraft'], ['vessel', 'Vessels']];
export function render(ctx) {
  db = ctx.db;
  state = { kind: ctx.query.get('kind') || '', country: ctx.query.get('country') || '', q: ctx.query.get('q') || '' };
  const kinds = uniq(db.entities.map((e) => e.kind).filter(Boolean)).map((k) => [k, KIND_LABEL[k] || k]);
  const countries = uniq(db.entities.flatMap((e) => e.countries || [])).map((c) => [c, countryName(c)]).sort((a, b) => a[1].localeCompare(b[1]));
  return {
    title: 'People & organizations',
    html: html`
    <header class="page-head"><p class="kicker">People &amp; organizations</p><h1 id="page-title" tabindex="-1">People &amp; organizations</h1>
    <p class="lede">Profiles of the individuals, units, state bodies, companies and outlets that appear in the record, with their documented roles, relationships and sanctions.</p></header>
    <p class="note-box"><strong>Only public figures and organizations are profiled.</strong> This database does not publish personal information about private individuals — no home addresses, phone numbers or family details.</p>
    <form class="filters" id="ppl-filters" role="search" aria-label="Filter profiles">
      <div class="f f-grow"><label for="p-q">Search names &amp; aliases</label><input id="p-q" type="search" name="q" value="${state.q}"></div>
      <div class="f"><label for="p-kind">Type</label><select id="p-kind" name="kind">${options(kinds, state.kind, 'All types')}</select></div>
      <div class="f"><label for="p-country">Country</label><select id="p-country" name="country">${options(countries, state.country, 'All countries')}</select></div>
    </form>
    <p id="ppl-count" role="status"></p>
    <div id="ppl-results"></div>`,
  };
}
function draw(root) {
  const q = state.q.toLowerCase().trim();
  const list = db.entities.filter((e) => (!state.kind || e.kind === state.kind) && (!state.country || (e.countries || []).includes(state.country)) && (!q || [e.name, ...(e.aliases || []), e.role].some((v) => typeof v === 'string' && v.toLowerCase().includes(q)))).sort((a, b) => a.name.localeCompare(b.name));
  root.querySelector('#ppl-count').textContent = `${list.length} of ${db.entities.length} profiles`;
  const known = new Set(GROUPS.map((g) => g[0]));
  const groups = [...GROUPS, ['__other', 'Other']].map(([k, l]) => [l, list.filter((e) => (k === '__other' ? !known.has(e.kind) : e.kind === k))]).filter(([, l]) => l.length);
  root.querySelector('#ppl-results').innerHTML = String(!list.length ? (db.entities.length ? html`<p class="empty">No profiles match.</p>` : empty()) : groups.map(([l, items]) => html`<section class="section"><h2>${l} <span class="mono" style="color:var(--muted);font-size:.9rem">(${items.length})</span></h2><div class="grid grid-3">${items.map((e) => html`<a class="card" href="#/entity/${encodeURIComponent(e.id)}"><h3>${e.name}</h3>${e.role ? html`<p>${e.role}</p>` : ''}<p class="card-meta">${KIND_LABEL[e.kind] || e.kind}${e.period ? ' · ' + e.period : ''}${(db.sanctionsByEntity.get(e.id) || []).length ? ` · ${plural(db.sanctionsByEntity.get(e.id).length, 'designation')}` : ''}</p></a>`)}</div></section>`));
}
export function mount(root) {
  const form = root.querySelector('#ppl-filters');
  const update = () => { setQuery('people', state); draw(root); };
  form.addEventListener('change', (e) => { if (e.target.tagName === 'SELECT') { state[e.target.name] = e.target.value; update(); } });
  form.querySelector('#p-q').addEventListener('input', debounce((e) => { state.q = e.target.value; update(); }, 150));
  form.addEventListener('submit', (e) => e.preventDefault());
  draw(root);
}
