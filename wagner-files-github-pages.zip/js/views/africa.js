import { html, statusLegend, statusChip, STATUS_ORDER, STATUS, renderPages, plural, empty, SECTION_LABEL } from '../ui.js';
import { pagesFor } from '../data.js';

let inst = null;
export function render({ db }) {
  const african = db.countries.filter((c) => c.region === 'Africa').sort((a, b) => a.name.localeCompare(b.name));
  const transition = pagesFor('transition');
  const accountability = pagesFor('accountability', 'A');
  const afIncidents = db.incidents.filter((i) => african.some((c) => c.iso3 === i.country));
  const byStatus = [...STATUS_ORDER, null].map((s) => [s, african.filter((c) => (s ? c.status === s : !STATUS[c.status]))]).filter(([, l]) => l.length);
  return {
    title: 'Africa',
    html: html`
    <header class="page-head"><p class="kicker">Africa</p><h1 id="page-title" tabindex="-1">Wagner and the Africa Corps in Africa</h1>
    <p class="lede">Country operations, host-government relationships, economic interests and documented abuses, and the transition from the Wagner Group to the Russian Ministry of Defence’s Africa Corps.</p>
    <div class="meta-line"><span>${plural(african.length, 'African country', 'African countries')} in the database</span><span>${plural(afIncidents.length, 'incident')}</span></div></header>
    <div class="two-col"><div>
    <section class="section" id="af-map" aria-labelledby="af-map-h"><h2 id="af-map-h">Map</h2>${statusLegend()}
      <div class="map-wrap small" style="margin-top:.8rem"><div id="africa-map" class="map" role="region" aria-label="Map of Africa by status. The country list below provides the same information."></div></div></section>
    <section class="section" id="af-countries" aria-labelledby="af-c-h"><h2 id="af-c-h">Country profiles</h2>
      ${african.length ? byStatus.map(([s, list]) => html`<h3>${s ? STATUS[s].label : 'Status not recognised'}</h3><div class="grid grid-3" style="margin-bottom:1.2rem">${list.map((c) => html`<a class="card" href="#/country/${c.iso3}"><h4>${c.name}</h4><p>${statusChip(c.status)}</p><p class="card-meta">${plural((db.incidentsByCountry.get(c.iso3) || []).length, 'incident')} · ${plural((c.entities_present || []).length + (c.companies || []).length, 'linked organization')}</p></a>`)}</div>`) : empty()}
    </section>
    <section class="section" id="af-transition" aria-labelledby="af-t-h"><h2 id="af-t-h">${SECTION_LABEL.transition}</h2>${renderPages(transition, { idPrefix: 'tr' })}</section>
    <section class="section" id="af-accountability" aria-labelledby="af-a-h"><h2 id="af-a-h">Accountability in Africa</h2>${renderPages(accountability, { idPrefix: 'acc' })}</section>
    <section class="section" id="af-more" aria-labelledby="af-m-h"><h2 id="af-m-h">Explore further</h2>
      <ul><li><a href="#/incidents">Incident database</a> (${plural(afIncidents.length, 'African incident')})</li><li><a href="#/money">Follow the money</a></li><li><a href="#/section/infoops">Information operations</a></li><li><a href="#/timeline?cat=africa">Africa timeline</a></li><li><a href="#/sanctions">Sanctions explorer</a></li></ul></section>
    </div>
    <nav class="toc" aria-label="On this page"><p class="kicker">On this page</p><ol>
      <li><a href="#/africa" data-scroll-to="af-map">Map</a></li><li><a href="#/africa" data-scroll-to="af-countries">Country profiles</a></li><li><a href="#/africa" data-scroll-to="af-transition">From Wagner to Africa Corps</a></li><li><a href="#/africa" data-scroll-to="af-accountability">Accountability</a></li></ol></nav></div>`,
  };
}
export async function mount(root, { db }) {
  const { createMap } = await import('../mapkit.js');
  inst = await createMap(root.querySelector('#africa-map'), { bounds: [[-36, -19], [38, 52]], onCountry: (iso) => (location.hash = `#/country/${iso}`), incidents: [] });
}
export function unmount() { inst?.destroy(); inst = null; }
