import { html, renderPages, SECTION_LABEL, plural, legend } from '../ui.js';
import { incidentTable, timelineList } from '../components.js';
import { pagesFor } from '../data.js';

const SECTIONS = ['history', 'ukraine', 'prison-recruitment', 'casualties', 'rebellion', 'prigozhin-crash', 'accountability'];
export function render({ db }) {
  const incidents = db.incidents.filter((i) => i.country === 'UKR' || String(i.id).startsWith('inc-ua-'));
  const tl = db.timeline.filter((t) => ['UKR', 'RUS', 'BLR'].includes(t.country) || ['origins', 'ukraine', 'rebellion'].includes(t.category));
  const blocks = SECTIONS.map((s) => [s, pagesFor(s, s === 'accountability' ? 'U' : null)]);
  const intro = { casualties: 'Estimates are listed side by side with who made them, when, how, and with what caveats. This database does not assert a single “true” figure.', 'prigozhin-crash': 'Established facts, official claims, intelligence assessments as reported, and speculation are kept separate.' };
  return {
    title: 'Ukraine',
    html: html`
    <header class="page-head"><p class="kicker">Ukraine</p><h1 id="page-title" tabindex="-1">Wagner in Ukraine, 2014 to the present</h1>
    <p class="lede">Origins, operations in Donbas and after the 2022 invasion, prison recruitment, casualty estimates, the June 2023 rebellion, the August 2023 crash, and accountability efforts.</p>
    <div class="meta-line"><span>${plural(incidents.length, 'Ukraine incident')}</span><span>${plural(tl.length, 'timeline event')}</span></div></header>
    ${legend({ compact: true })}
    <div class="two-col" style="margin-top:1rem"><div>
    ${blocks.map(([s, pages]) => html`<section class="section" id="ua-${s}" aria-labelledby="ua-${s}-h"><h2 id="ua-${s}-h">${SECTION_LABEL[s]}</h2>${intro[s] ? html`<p class="note-box">${intro[s]}</p>` : ''}${renderPages(pages, { idPrefix: 'ua' })}</section>`)}
    <section class="section" id="ua-incidents" aria-labelledby="ua-inc-h"><h2 id="ua-inc-h">Ukraine incidents</h2>${incidentTable(incidents, { caption: 'Incidents in Ukraine', showCountry: false, limit: 60 })}${incidents.length ? html`<p><a href="#/incidents?country=UKR">Open the full filtered incident database →</a></p>` : ''}</section>
    <section class="section" id="ua-timeline" aria-labelledby="ua-tl-h"><h2 id="ua-tl-h">Timeline</h2>${timelineList(tl, { idPrefix: 'uatl' })}</section>
    </div>
    <nav class="toc" aria-label="On this page"><p class="kicker">On this page</p><ol>${SECTIONS.map((s) => html`<li><a href="#/ukraine" data-scroll-to="ua-${s}">${SECTION_LABEL[s]}</a></li>`)}<li><a href="#/ukraine" data-scroll-to="ua-incidents">Ukraine incidents</a></li><li><a href="#/ukraine" data-scroll-to="ua-timeline">Timeline</a></li></ol></nav>
    </div>`,
  };
}
