import { html, raw, fmtDate, download, empty, entityLink, incidentTitle } from '../ui.js';

import { PAGE_ROUTE } from './source.js';
const pageHref = (p) => PAGE_ROUTE[p.section] || (p.section === 'accountability' ? '#/ukraine' : `#/section/${p.section}`);
function describe(db, id) {
  if (!id) return null;
  const blk = /^(page-[^\[]+)\[([\d.]+)\]$/.exec(id);
  if (blk && db.pageById.has(blk[1])) { const p = db.pageById.get(blk[1]); return ['Long-form section', `${p.title} (block ${blk[2]})`, pageHref(p)]; }
  if (db.incidentById.has(id)) return ['Incident', incidentTitle(db.incidentById.get(id)), `#/incident/${encodeURIComponent(id)}`];
  if (db.entityById.has(id)) return ['Profile', db.entityById.get(id).name, `#/entity/${encodeURIComponent(id)}`];
  if (db.countryByIso.has(id)) return ['Country profile', db.countryByIso.get(id).name, `#/country/${id}`];
  if (db.sourceById.has(id)) return ['Source', db.sourceById.get(id).title, `#/source/${encodeURIComponent(id)}`];
  if (db.sanctionById.has(id)) return ['Sanctions designation', db.sanctionById.get(id).name_as_listed, '#/sanctions'];
  if (db.relById.has(id)) return ['Relationship', id, '#/network'];
  if (db.timelineById.has(id)) return ['Timeline event', db.timelineById.get(id).title, `#/timeline?focus=${encodeURIComponent(id)}`];
  if (db.pageById.has(id)) return ['Long-form section', db.pageById.get(id).title, pageHref(db.pageById.get(id))];
  if (db.unprovenById.has(id)) return ['Unproven claim', db.unprovenById.get(id).claim, '#/findings'];
  if (/^finding-\d+$/.test(id)) return ['Finding', `Finding ${id.split('-')[1]}`, '#/findings'];
  return ['Unknown record', 'This identifier is not in the current data', null];
}
let db;
export function render(ctx) {
  db = ctx.db;
  const item = ctx.query.get('item') || '';
  const cfg = db.config.corrections || {};
  const d = describe(db, item);
  const log = [...db.corrections].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')) || String(a.id || '').localeCompare(String(b.id || '')));
  const types = Object.entries(log.reduce((m, c) => { if (c.type) m[c.type] = (m[c.type] || 0) + 1; return m; }, {})).sort((a, b) => b[1] - a[1]);
  return {
    title: 'Corrections',
    html: html`
    <header class="page-head"><p class="kicker">Corrections</p><h1 id="page-title" tabindex="-1">Report an error</h1>
    <p class="lede">Found a factual error, a broken link, a mis-graded claim or a missing source? Compose a structured correction below. Nothing is sent from this page: you download the correction or open it in your email client or as a GitHub issue.</p></header>
    ${cfg.PLACEHOLDER ? html`<p class="placeholder-warn" role="note"><strong>Placeholder destination.</strong> The corrections email (${cfg.email}) and GitHub repository (${cfg.github_repo}) are placeholders set in <code>config/site.config.json</code>. They must be replaced before publication.</p>` : ''}
    <form class="form-grid" id="corr-form" novalidate style="margin-top:1.2rem">
      <div class="f"><label for="c-item">Item ID</label><input id="c-item" name="item_id" type="text" value="${item}" aria-describedby="c-item-help" autocomplete="off" spellcheck="false">
        <span class="help" id="c-item-help">${d ? html`${d[0]}: ${d[2] ? html`<a href="${d[2]}">${d[1]}</a>` : d[1]}` : 'Filled in automatically when you use a “Report an error” link. You can also type any record ID.'}</span></div>
      <div class="f"><label for="c-error">What is wrong? <span aria-hidden="true">*</span></label><textarea id="c-error" name="claimed_error" required aria-required="true" placeholder="Quote the statement and explain the error."></textarea></div>
      <div class="f"><label for="c-fix">Proposed correction <span aria-hidden="true">*</span></label><textarea id="c-fix" name="proposed_correction" required aria-required="true" placeholder="What should it say instead?"></textarea></div>
      <div class="f"><label for="c-url">Supporting source URL</label><input id="c-url" name="supporting_source_url" type="url" placeholder="https://" inputmode="url"><span class="help">A primary source is most useful. Please do not include personal information about private individuals.</span></div>
      <div class="f"><label for="c-contact">Your name or email (optional)</label><input id="c-contact" name="contact" type="text" autocomplete="off"><span class="help">Only needed if you want a reply. Leave blank to stay anonymous.</span></div>
      <p id="c-errors" class="help" role="alert" style="color:var(--c-disputed)"></p>
      <div class="btn-row"><button type="submit" class="btn">Download correction (JSON)</button><a class="btn btn-quiet" id="c-mail" href="#">Open in email</a><a class="btn btn-quiet" id="c-gh" href="#" target="_blank" rel="noopener noreferrer">Open GitHub issue</a></div>
      <details><summary>Preview the structured correction</summary><pre class="output-box" id="c-preview" tabindex="0" aria-label="Correction JSON preview"></pre></details>
    </form>
    <section class="section" aria-labelledby="h-log"><h2 id="h-log">Public corrections log</h2>
    ${log.length ? html`<p class="help">${log.length} published correction${log.length === 1 ? '' : 's'}${types.length ? html` · ${types.map(([t, n], i) => html`${i ? ', ' : ''}${t} (${n})`)}` : ''}.</p>
    <div class="table-wrap cards"><table class="data responsive corr-log"><caption class="visually-hidden">Published corrections</caption><thead><tr><th scope="col">Date</th><th scope="col">Item</th><th scope="col">Type</th><th scope="col">Correction</th><th scope="col">Change</th></tr></thead><tbody>${log.map((c) => { const dd = describe(db, c.item_id); const same = !c.summary || !c.correction || c.summary.trim() === c.correction.trim(); return html`<tr id="${c.id || ''}"><td data-label="Date" class="nowrap mono">${fmtDate(c.date)}</td><td data-label="Item">${dd && dd[2] ? html`<a href="${dd[2]}">${dd[1]}</a><div class="id-line">${c.item_id}</div>` : html`<span class="mono">${c.item_id}</span>${c.type === 'removal' ? html`<div class="id-line">Record removed</div>` : ''}`}</td><td data-label="Type">${c.type ? html`<span class="tag">${c.type}</span>` : '—'}</td><td data-label="Correction">${c.summary ? html`<strong>${c.summary}</strong>` : ''}${!same ? html` ${c.correction}` : !c.summary ? c.correction || '' : ''}</td><td data-label="Change">${c.before || c.after ? html`<div class="corr-diff"><span class="visually-hidden">Before: </span><del>${c.before || '—'}</del> <span aria-hidden="true">→</span> <span class="visually-hidden">After: </span><ins>${c.after || '—'}</ins></div>` : '—'}</td></tr>`; })}</tbody></table></div>` : html`<p class="empty">No corrections have been published yet.</p>`}
    </section>`,
  };
}
export function mount(root) {
  const form = root.querySelector('#corr-form');
  const cfg = db.config.corrections || {};
  const build = () => {
    const f = new FormData(form);
    const id = String(f.get('item_id') || '').trim();
    const d = describe(db, id);
    return { type: 'wagner-files-correction', version: 1, created: new Date().toISOString(), page: location.href, item_id: id || null, item_type: d ? d[0] : null, item_label: d ? d[1] : null, claimed_error: String(f.get('claimed_error') || '').trim(), proposed_correction: String(f.get('proposed_correction') || '').trim(), supporting_source_url: String(f.get('supporting_source_url') || '').trim() || null, contact: String(f.get('contact') || '').trim() || null };
  };
  const refresh = () => {
    const c = build();
    root.querySelector('#c-preview').textContent = JSON.stringify(c, null, 2);
    const title = `${cfg.email_subject_prefix || '[Correction]'} ${c.item_id || 'general'}`;
    const body = `Item: ${c.item_id || '(none)'}${c.item_label ? ' — ' + c.item_label : ''}\n\nClaimed error:\n${c.claimed_error}\n\nProposed correction:\n${c.proposed_correction}\n\nSupporting source: ${c.supporting_source_url || '(none)'}\n\n---\n${JSON.stringify(c)}`;
    root.querySelector('#c-mail').href = `mailto:${encodeURIComponent(cfg.email || '')}?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(body)}`;
    root.querySelector('#c-gh').href = `https://github.com/${cfg.github_repo || 'OWNER/REPO'}/issues/new?title=${encodeURIComponent(title)}&body=${encodeURIComponent(body)}&labels=correction`;
  };
  const validate = () => {
    const c = build(); const errs = [];
    if (!c.claimed_error) errs.push('Describe the error.');
    if (!c.proposed_correction) errs.push('Propose a correction.');
    if (c.supporting_source_url && !/^https?:\/\/\S+$/.test(c.supporting_source_url)) errs.push('The supporting source must be an http(s) URL.');
    root.querySelector('#c-errors').textContent = errs.join(' ');
    root.querySelector('#c-error').setAttribute('aria-invalid', String(!c.claimed_error));
    root.querySelector('#c-fix').setAttribute('aria-invalid', String(!c.proposed_correction));
    return errs.length === 0;
  };
  form.addEventListener('input', refresh);
  form.addEventListener('submit', (e) => { e.preventDefault(); if (!validate()) return; const c = build(); download(`correction-${c.item_id || 'general'}-${Date.now()}.json`, JSON.stringify(c, null, 2)); });
  ['#c-mail', '#c-gh'].forEach((sel) => root.querySelector(sel).addEventListener('click', (e) => { refresh(); if (!validate()) e.preventDefault(); }));
  refresh();
}
