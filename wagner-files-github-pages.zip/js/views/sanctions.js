import { startCitations } from '../ui.js';
import { html, raw, options, setQuery, debounce, toCSV, download, uniq, fmtDate, cites, entityLink, empty, announce, plural } from '../ui.js';
import { entityName, yearOf } from '../data.js';

const AUTH_LABEL = { 'US-OFAC': 'US Treasury (OFAC)', 'US-State': 'US State Department', EU: 'European Union', UK: 'United Kingdom', CA: 'Canada', AU: 'Australia', UN: 'United Nations', CH: 'Switzerland', JP: 'Japan', NZ: 'New Zealand', UA: 'Ukraine', other: 'Other' };
const KIND = { person: 'Person', entity: 'Entity', aircraft: 'Aircraft', vessel: 'Vessel' };
const FIELDS = ['authority', 'year', 'kind', 'org', 'q'];
let db, state;

export function render(ctx) {
  db = ctx.db;
  state = Object.fromEntries(FIELDS.map((f) => [f, ctx.query.get(f) || '']));
  const S = db.sanctions;
  const auths = uniq(S.map((s) => s.authority).filter(Boolean)).sort().map((a) => [a, AUTH_LABEL[a] || a]);
  const years = uniq(S.map((s) => yearOf(s.date)).filter(Boolean)).sort().reverse().map((y) => [y, y]);
  const kinds = uniq(S.map((s) => s.kind).filter(Boolean)).map((k) => [k, KIND[k] || k]);
  const orgs = uniq(S.flatMap((s) => s.related_org || [])).map((o) => [o, entityName(o)]).sort((a, b) => a[1].localeCompare(b[1]));
  const byAuth = auths.map(([a, l]) => [l, S.filter((s) => s.authority === a).length]).sort((a, b) => b[1] - a[1]);
  const byYear = uniq(S.map((s) => yearOf(s.date)).filter(Boolean)).sort().map((y) => [y, S.filter((s) => yearOf(s.date) === y).length]);
  const max = Math.max(1, ...byAuth.map((x) => x[1]), ...byYear.map((x) => x[1]));
  const bars = (list) => html`<ul class="hbar-list">${list.map(([l, n]) => html`<li><span>${l}</span><span class="track"><span class="fill" style="width:${(100 * n) / max}%"></span></span><span class="n">${n}</span></li>`)}</ul>`;
  return {
    title: 'Sanctions explorer',
    html: html`
    <header class="page-head"><p class="kicker">Sanctions explorer</p><h1 id="page-title" tabindex="-1">Sanctions explorer</h1>
    <p class="lede">Designations of Wagner-linked people, entities, aircraft and vessels. A designation confirms that the authority made it and its stated basis; the underlying conduct is described “according to” that authority and graded separately elsewhere on this site.</p>
    <div class="meta-line"><span>${plural(S.length, 'designation')}</span><span>${plural(db.meta.stats.sanctioned_entities, 'distinct target')}</span></div></header>
    ${S.length ? html`<div class="grid grid-2" style="margin-bottom:1.5rem"><div class="card"><h2 class="h3" style="font-size:1rem">Designations by authority</h2>${bars(byAuth)}</div><div class="card"><h2 style="font-size:1rem">Designations by year</h2>${bars(byYear)}</div></div>` : ''}
    <form class="filters" id="san-filters" role="search" aria-label="Filter sanctions">
      <div class="f f-grow"><label for="s-q">Search</label><input id="s-q" type="search" name="q" value="${state.q}" placeholder="Name, program, reason…"></div>
      <div class="f"><label for="s-auth">Authority</label><select id="s-auth" name="authority">${options(auths, state.authority, 'All authorities')}</select></div>
      <div class="f"><label for="s-year">Year</label><select id="s-year" name="year">${options(years, state.year, 'All years')}</select></div>
      <div class="f"><label for="s-kind">Kind</label><select id="s-kind" name="kind">${options(kinds, state.kind, 'All kinds')}</select></div>
      <div class="f"><label for="s-org">Related organization</label><select id="s-org" name="org">${options(orgs, state.org, 'All organizations')}</select></div>
      <div class="f"><button type="reset" class="btn btn-quiet">Clear filters</button></div>
    </form>
    <div class="results-bar"><p id="san-count" role="status" style="margin:0"></p><div class="btn-row"><button type="button" class="btn btn-quiet btn-small" id="s-csv">Export CSV</button><button type="button" class="btn btn-quiet btn-small" id="s-json">Export JSON</button></div></div>
    <div id="san-results"></div>`,
  };
}
function filtered() {
  const q = state.q.toLowerCase().trim();
  return db.sanctions.filter((s) => (!state.authority || s.authority === state.authority) && (!state.year || yearOf(s.date) === state.year) && (!state.kind || s.kind === state.kind) && (!state.org || (s.related_org || []).includes(state.org)) &&
    (!q || [s.name_as_listed, s.program, s.reason, s.jurisdiction, entityName(s.target_entity)].some((v) => typeof v === 'string' && v.toLowerCase().includes(q))))
    .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
}
function draw(root) {
  startCitations();
  const list = filtered();
  root.querySelector('#san-count').textContent = `${list.length} of ${db.sanctions.length} designations match`;
  root.querySelector('#san-results').innerHTML = String(!list.length ? (db.sanctions.length ? html`<p class="empty">No designations match these filters.</p>` : empty()) : html`<div class="table-wrap cards"><table class="data responsive"><caption class="visually-hidden">Designations matching the filters</caption>
  <thead><tr><th scope="col">Person / entity</th><th scope="col">Kind</th><th scope="col">Authority</th><th scope="col">Date</th><th scope="col">Jurisdiction</th><th scope="col">Stated reason</th><th scope="col">Related organization</th><th scope="col">Official source</th></tr></thead>
  <tbody>${list.map((s) => html`<tr>
    <td data-label="Person / entity">${db.entityById.has(s.target_entity) ? html`<a class="row-title" href="#/entity/${encodeURIComponent(s.target_entity)}">${s.name_as_listed || entityName(s.target_entity)}</a>` : html`<span class="row-title">${s.name_as_listed}</span> <span class="mono">(${s.target_entity} missing)</span>`}${s.program ? html`<div class="card-meta">${s.program}</div>` : ''}</td>
    <td data-label="Kind">${KIND[s.kind] || s.kind}</td><td data-label="Authority">${AUTH_LABEL[s.authority] || s.authority}</td><td data-label="Date" class="nowrap mono">${fmtDate(s.date)}</td><td data-label="Jurisdiction">${s.jurisdiction || '—'}</td>
    <td data-label="Stated reason">${s.reason ? html`According to the designating authority: ${s.reason}` : html`<span class="empty">Insufficient verified information.</span>`} ${cites(s.source_ids)}</td>
    <td data-label="Related organization">${(s.related_org || []).length ? s.related_org.map((o, i) => html`${i ? ', ' : ''}${entityLink(o)}`) : '—'}</td>
    <td data-label="Official source">${s.official_url ? html`<a href="${s.official_url}" target="_blank" rel="noopener noreferrer">Official notice<span class="visually-hidden"> for ${s.name_as_listed} (opens in new tab)</span></a>` : html`<span class="empty">Not recorded</span>`}</td></tr>`)}</tbody></table></div>`);
  import('../app.js').then((m) => m.refreshEndnotes());
}
export function mount(root) {
  const form = root.querySelector('#san-filters');
  const update = () => { setQuery('sanctions', state); draw(root); announce(root.querySelector('#san-count').textContent); };
  form.addEventListener('change', (e) => { if (e.target.name && e.target.tagName === 'SELECT') { state[e.target.name] = e.target.value; update(); } });
  form.querySelector('#s-q').addEventListener('input', debounce((e) => { state.q = e.target.value; update(); }, 200));
  form.addEventListener('submit', (e) => e.preventDefault());
  form.addEventListener('reset', () => setTimeout(() => { FIELDS.forEach((f) => (state[f] = '')); update(); }, 0));
  const cols = ['id', 'target_entity', 'name_as_listed', 'kind', 'authority', 'program', 'date', 'jurisdiction', 'reason', 'related_org', 'official_url', 'source_ids'].map((k) => ({ label: k, get: (s) => s[k] }));
  root.querySelector('#s-csv').addEventListener('click', () => download('wagner-files-sanctions.csv', toCSV(filtered(), cols), 'text/csv'));
  root.querySelector('#s-json').addEventListener('click', () => download('wagner-files-sanctions.json', JSON.stringify(filtered().map(({ _file, ...r }) => r), null, 2)));
  draw(root);
}
