import { html, badge, CONF_ORDER, CONF, STATUS, STATUS_ORDER, legend, cites, plural, fmtDate, empty } from '../ui.js';

export function render({ db }) {
  const st = db.meta.stats;
  const nInc = db.incidents.length;
  const confBar = nInc
    ? html`<div class="bar" aria-hidden="true">${CONF_ORDER.map((c) => (st.incidents_by_confidence[c] ? html`<span style="width:${(100 * st.incidents_by_confidence[c]) / nInc}%;background:var(--c-${c})"></span>` : ''))}</div>
      <ul class="hbar-list">${CONF_ORDER.map((c) => html`<li><span>${badge(c)}</span><span class="track"><span class="fill" style="width:${nInc ? (100 * (st.incidents_by_confidence[c] || 0)) / nInc : 0}%;background:var(--c-${c})"></span></span><span class="n">${st.incidents_by_confidence[c] || 0}</span></li>`)}</ul>`
    : html`<p class="sub">No incidents recorded yet.</p>`;
  const nCountries = db.countries.length;
  const statusList = html`<ul class="hbar-list">${STATUS_ORDER.map((s) => html`<li><span style="font-size:.78rem">${STATUS[s].label}</span><span class="track"><span class="fill" style="width:${nCountries ? (100 * (st.countries_by_status[s] || 0)) / nCountries : 0}%;background:var(--s-${s})"></span></span><span class="n">${st.countries_by_status[s] || 0}</span></li>`)}</ul>`;
  const findings = db.findings.slice(0, 5);
  const areas = [
    ['#/summary', 'Executive summary', 'The investigation in brief.', `${(db.pagesBySection.get('executive-summary') || []).length} section(s)`],
    ['#/map', 'Global map', 'Where Wagner and Africa Corps have been documented, country by country.', plural(nCountries, 'country', 'countries')],
    ['#/ukraine', 'Ukraine', 'Donbas 2014, the 2022 invasion, prison recruitment, Bakhmut, the rebellion and the crash.', plural(db.incidents.filter((i) => i.country === 'UKR').length, 'incident')],
    ['#/africa', 'Africa', 'Country operations and the transition from Wagner to the Africa Corps.', plural(db.countries.filter((c) => c.region === 'Africa').length, 'country', 'countries')],
    ['#/incidents', 'Incident database', 'Alleged and documented abuses, each graded and sourced.', plural(nInc, 'incident')],
    ['#/network', 'Network', 'Relationships between state bodies, units, leaders, companies and partners.', plural(db.relationships.length, 'relationship')],
    ['#/money', 'Follow the money', 'Gold, diamonds, concessions, security contracts and corporate structures.', plural((db.pagesBySection.get('money') || []).length, 'section')],
    ['#/sanctions', 'Sanctions explorer', 'Designations by the US, EU, UK and others.', plural(db.sanctions.length, 'designation')],
    ['#/people', 'People & organizations', 'Profiles of public figures and organizations.', plural(db.entities.length, 'profile')],
    ['#/timeline', 'Timeline', 'From the group’s origins to the present.', plural(db.timeline.length, 'event')],
    ['#/section/infoops', 'Information operations', 'Influence campaigns and media networks.', plural((db.pagesBySection.get('infoops') || []).length, 'section')],
    ['#/library', 'Document library', 'Every source, with what cites it.', plural(db.sources.length, 'source')],
  ];
  return {
    title: 'Home',
    html: html`
    <section class="hero" aria-labelledby="page-title">
      <p class="kicker">Open-source investigation · evidence-graded</p>
      <h1 id="page-title" tabindex="-1"><span class="accent-bar" aria-hidden="true"></span>${db.config.title}</h1>
      <p class="lede">${db.config.subtitle}</p>
      <p class="prose" style="color:var(--text-2)">This is an accountability record, not an indictment. Every statement is graded by the strength of its evidence and linked to its sources. Confirmed findings, strongly corroborated reporting, credible allegations, disputed claims and unverified claims are kept visibly separate. Statements by the Russian, Ukrainian and African governments, and by Wagner or the Africa Corps, are recorded as party claims, never as verification.</p>
      <p class="btn-row"><a class="btn" href="#/summary">Read the executive summary</a><a class="btn btn-quiet" href="#/methodology">How we grade evidence</a><a class="btn btn-quiet" href="#/findings">Best-documented findings</a></p>
    </section>

    <section class="section" aria-labelledby="h-stats">
      <h2 id="h-stats" class="section-title">The database at a glance</h2>
      <div class="grid grid-4">
        <div class="stat"><div class="num">${nInc.toLocaleString('en-US')}</div><div class="lbl">incidents, by evidence grade</div>${confBar}</div>
        <div class="stat"><div class="num">${nCountries}</div><div class="lbl">countries profiled</div>${statusList}</div>
        <div class="stat"><div class="num">${st.sanctioned_entities}</div><div class="lbl">sanctioned people, entities, aircraft &amp; vessels</div><div class="sub">${plural(st.designations, 'designation')} recorded across authorities</div></div>
        <div class="stat"><div class="num">${db.sources.length.toLocaleString('en-US')}</div><div class="lbl">sources in the library</div><div class="sub">${plural(st.primary_sources, 'primary source')}</div></div>
      </div>
      <p class="meta-line" style="margin-top:.8rem">Data last updated ${fmtDate(db.meta.last_updated)}. Figures are computed directly from the published records.</p>
    </section>

    <section class="section" aria-labelledby="h-legend">
      <h2 id="h-legend" class="section-title">How to read this database</h2>
      ${legend()}
      <p class="principle" style="margin-top:1rem">Absence from this database does not imply innocence or guilt.</p>
    </section>

    <section class="section" aria-labelledby="h-findings">
      <div class="section-title-row"><h2 id="h-findings" class="section-title" style="flex:1">Major findings</h2><a href="#/findings">All best-documented findings →</a></div>
      ${findings.length ? html`<ol class="finding-list">${findings.map((f) => html`<li class="finding"><span class="rank">${String(f.rank ?? '').padStart(2, '0')}</span><div><p class="ftext">${f.finding} ${cites([...(f.primary_source_ids || []), ...(f.corroboration_source_ids || [])])}</p><div class="fmeta">${badge(f.confidence)}${f.period ? html`<span>${f.period}</span>` : ''}${f.location ? html`<span>${f.location}</span>` : ''}</div></div></li>`)}</ol>` : empty()}
    </section>

    <section class="section" aria-labelledby="h-areas">
      <h2 id="h-areas" class="section-title">Investigation areas</h2>
      <div class="grid grid-3">${areas.map(([href, t, d, c]) => html`<a class="card area-card" href="${href}"><h3>${t}</h3><p>${d}</p><span class="count">${c}</span></a>`)}</div>
    </section>`,
  };
}
