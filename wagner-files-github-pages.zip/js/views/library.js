import { html, raw, options, setQuery, debounce, SRC_CAT, SRC_CAT_ORDER, fmtDate, empty, plural } from '../ui.js';

let db, state;
const PER_GROUP = 40;
const expanded = new Set();
export function render(ctx) {
  db = ctx.db;
  state = { q: ctx.query.get('q') || '', cat: ctx.query.get('cat') || '', primary: ctx.query.get('primary') || '' };
  expanded.clear();
  return {
    title: 'Document library',
    html: html`
    <header class="page-head"><p class="kicker">Document library</p><h1 id="page-title" tabindex="-1">Document library</h1>
    <p class="lede">Every source cited in the database, grouped by type. Each source page lists every claim, incident, profile and designation that relies on it.</p>
    <div class="meta-line"><span>${plural(db.sources.length, 'source')}</span><span>${plural(db.meta.stats.primary_sources, 'primary source')}</span></div></header>
    <p class="note-box">Party statements (from the Russian, Ukrainian or African governments, or from Wagner / Africa Corps) are kept in their own group: they document what a party claimed and are never treated as independent verification.</p>
    <form class="filters" id="lib-filters" role="search" aria-label="Search sources">
      <div class="f f-grow"><label for="l-q">Search title, publisher, summary</label><input id="l-q" type="search" name="q" value="${state.q}"></div>
      <div class="f"><label for="l-cat">Category</label><select id="l-cat" name="cat">${options(SRC_CAT_ORDER.map((c) => [c, SRC_CAT[c]]), state.cat, 'All categories')}</select></div>
      <div class="f"><label for="l-primary">Primary / secondary</label><select id="l-primary" name="primary">${options([['1', 'Primary sources'], ['0', 'Secondary sources']], state.primary, 'All')}</select></div>
    </form>
    <p id="lib-count" role="status"></p>
    <div id="lib-results"></div>`,
  };
}
function draw(root) {
  const q = state.q.toLowerCase().trim();
  const list = db.sources.filter((s) => (!state.cat || s.category === state.cat) && (!state.primary || String(s.primary === true ? 1 : 0) === state.primary) && (!q || [s.title, s.publisher, s.summary, s.author, s.id].some((v) => typeof v === 'string' && v.toLowerCase().includes(q))));
  root.querySelector('#lib-count').textContent = `${list.length} of ${db.sources.length} sources`;
  const cats = [...SRC_CAT_ORDER, '__other'];
  const groups = cats.map((c) => [c, list.filter((s) => (c === '__other' ? !SRC_CAT[s.category] : s.category === c)).sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')))]).filter(([, l]) => l.length);
  root.querySelector('#lib-results').innerHTML = String(!list.length ? (db.sources.length ? html`<p class="empty">No sources match.</p>` : empty()) : groups.map(([c, items]) => {
    const show = expanded.has(c) ? items : items.slice(0, PER_GROUP);
    return html`<details class="group" open><summary><span>${SRC_CAT[c] || 'Uncategorised'}</span><span class="count">${items.length}</span></summary><div class="group-body"><ul class="src-list">${show.map((s) => html`<li class="src-item"><a class="src-title" href="#/source/${encodeURIComponent(s.id)}">${s.title}</a><div class="src-meta">${s.publisher || ''}${s.author ? ' · ' + s.author : ''}${s.date ? ' · ' + fmtDate(s.date) : ''}${s.primary === true ? ' · primary' : ''} · cited ${plural((db.backlinks[s.id] || []).length, 'time')}</div>${s.summary ? html`<p class="src-sum">${s.summary}</p>` : ''}</li>`)}</ul>
    ${show.length < items.length ? html`<button type="button" class="btn btn-quiet btn-small" data-expand="${c}">Show all ${items.length} in ${SRC_CAT[c] || 'this group'}</button>` : ''}</div></details>`;
  }));
}
export function mount(root) {
  const form = root.querySelector('#lib-filters');
  const update = () => { setQuery('library', state); draw(root); };
  form.addEventListener('change', (e) => { if (e.target.tagName === 'SELECT') { state[e.target.name] = e.target.value; update(); } });
  form.querySelector('#l-q').addEventListener('input', debounce((e) => { state.q = e.target.value; update(); }, 200));
  form.addEventListener('submit', (e) => e.preventDefault());
  root.querySelector('#lib-results').addEventListener('click', (e) => { const b = e.target.closest('[data-expand]'); if (b) { expanded.add(b.dataset.expand); draw(root); } });
  draw(root);
}
