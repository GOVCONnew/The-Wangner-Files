import { startCitations } from '../ui.js';
import { html, raw, options, setQuery, TL_CAT_LABEL, CONF_ORDER, CONF, uniq, empty, announce } from '../ui.js';
import { timelineList } from '../components.js';
import { countryName } from '../data.js';

let db, state;
export function render(ctx) {
  db = ctx.db;
  state = { cat: ctx.query.get('cat') || '', country: ctx.query.get('country') || '', conf: ctx.query.get('conf') || '', focus: ctx.query.get('focus') || '' };
  const cats = Object.keys(TL_CAT_LABEL).filter((c) => db.timeline.some((t) => t.category === c));
  const countries = uniq(db.timeline.map((t) => t.country).filter(Boolean)).map((c) => [c, countryName(c)]).sort((a, b) => a[1].localeCompare(b[1]));
  return {
    title: 'Timeline',
    html: html`
    <header class="page-head"><p class="kicker">Timeline</p><h1 id="page-title" tabindex="-1">Timeline</h1>
    <p class="lede">From the group’s origins through Ukraine, Syria and Africa, the 2022 invasion, prison recruitment, Bakhmut, the June 2023 rebellion, Prigozhin’s death, restructuring and the Africa Corps, to the present.</p></header>
    <nav aria-label="Jump to era"><p class="kicker" style="margin-bottom:.3rem">Jump to era</p><div class="era-nav">${db.eras.map((e) => html`<button type="button" class="chip" data-era="${e.id}">${e.label}</button>`)}</div></nav>
    <form class="filters" id="tl-filters" aria-label="Filter timeline">
      <div class="f"><label for="tl-cat">Category</label><select id="tl-cat" name="cat">${options(cats.map((c) => [c, TL_CAT_LABEL[c]]), state.cat, 'All categories')}</select></div>
      <div class="f"><label for="tl-country">Country</label><select id="tl-country" name="country">${options(countries, state.country, 'All countries')}</select></div>
      <div class="f"><label for="tl-conf">Evidence grade</label><select id="tl-conf" name="conf">${options(CONF_ORDER.map((c) => [c, CONF[c].short]), state.conf, 'All grades')}</select></div>
    </form>
    <p id="tl-count" role="status"></p>
    <h2 class="visually-hidden">Events</h2>
    <div id="tl-results"></div>`,
  };
}
const filtered = () => db.timeline.filter((t) => (!state.cat || t.category === state.cat) && (!state.country || t.country === state.country) && (!state.conf || t.confidence === state.conf));
function draw(root) {
  startCitations();
  const list = filtered();
  root.querySelector('#tl-count').textContent = `${list.length} of ${db.timeline.length} events`;
  root.querySelector('#tl-results').innerHTML = String(list.length ? timelineList(list, { idPrefix: 'tl' }) : db.timeline.length ? html`<p class="empty">No events match these filters.</p>` : empty());
  import('../app.js').then((m) => m.refreshEndnotes());
}
export function mount(root) {
  const form = root.querySelector('#tl-filters');
  form.addEventListener('change', (e) => { state[e.target.name] = e.target.value; state.focus = ''; setQuery('timeline', state); draw(root); announce(root.querySelector('#tl-count').textContent); });
  root.querySelector('.era-nav').addEventListener('click', (e) => {
    const b = e.target.closest('[data-era]');
    if (!b) return;
    const era = db.eras.find((x) => x.id === b.dataset.era);
    const items = [...root.querySelectorAll('.tl-item')];
    const target = (era.category && items.find((li) => li.dataset.date >= era.from && li.querySelector('.tag')?.textContent === TL_CAT_LABEL[era.category])) || items.find((li) => li.dataset.date >= era.from);
    root.querySelectorAll('[data-era]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    if (!target) { announce(`No events on or after ${era.label} with the current filters`); return; }
    target.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
    target.setAttribute('tabindex', '-1'); target.focus({ preventScroll: true });
    announce(`Jumped to ${era.label}`);
  });
  draw(root);
  if (state.focus) { const el = root.querySelector(`#tl-${CSS.escape(state.focus)}`); if (el) { el.scrollIntoView({ block: 'center' }); el.setAttribute('tabindex', '-1'); el.focus({ preventScroll: true }); el.style.outline = '1px solid var(--focus)'; } }
}
