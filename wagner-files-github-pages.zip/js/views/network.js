import { html, raw, options, setQuery, KIND_LABEL, REL_LABEL, CONF_ORDER, CONF, badge, uniq, empty, announce, confRank, plural } from '../ui.js';
import { relationshipTable } from '../components.js';
import { countryName } from '../data.js';
import { tierColor } from '../graphkit.js';

let graph = null, db, state;
export function render(ctx) {
  db = ctx.db;
  state = { country: ctx.query.get('country') || '', kind: ctx.query.get('kind') || '', type: ctx.query.get('type') || '', conf: ctx.query.get('conf') || '', view: ctx.query.get('view') === 'list' ? 'list' : 'graph', focus: ctx.query.get('focus') || '' };
  const countries = uniq(db.entities.flatMap((e) => e.countries || [])).map((c) => [c, countryName(c)]).sort((a, b) => a[1].localeCompare(b[1]));
  const kinds = uniq(db.entities.map((e) => e.kind).filter(Boolean)).map((k) => [k, KIND_LABEL[k] || k]);
  const types = uniq(db.relationships.map((r) => r.type).filter(Boolean)).map((t) => [t, REL_LABEL[t] || t]);
  const confs = CONF_ORDER.map((c) => [c, `${CONF[c].short} or stronger`]);
  return {
    title: 'Network',
    html: html`
    <header class="page-head"><p class="kicker">Network</p><h1 id="page-title" tabindex="-1">The network</h1>
    <p class="lede">Documented relationships between the Russian state, security services, Wagner and the Africa Corps, their leaders, companies, logistics, resource interests, host governments and local partners. Every connection carries an evidence grade and sources.</p>
    <div class="meta-line"><span>${plural(db.entities.length, 'entity', 'entities')}</span><span>${plural(db.relationships.length, 'relationship')}</span></div></header>
    <form class="filters" id="net-filters" aria-label="Filter the network">
      <div class="f f-grow"><label for="net-search">Find an entity</label><input id="net-search" type="search" list="net-names" placeholder="Type a name and press Enter" value="${state.focus ? db.entityById.get(state.focus)?.name || '' : ''}"><datalist id="net-names">${db.entities.map((e) => html`<option value="${e.name}"></option>`)}</datalist></div>
      <div class="f"><label for="net-country">Country</label><select id="net-country" name="country">${options(countries, state.country, 'All countries')}</select></div>
      <div class="f"><label for="net-kind">Entity type</label><select id="net-kind" name="kind">${options(kinds, state.kind, 'All types')}</select></div>
      <div class="f"><label for="net-type">Relationship</label><select id="net-type" name="type">${options(types, state.type, 'All relationships')}</select></div>
      <div class="f"><label for="net-conf">Evidence</label><select id="net-conf" name="conf">${options(confs, state.conf, 'All grades')}</select></div>
    </form>
    <div class="graph-toolbar">
      <div class="btn-row" role="group" aria-label="View">
        <button type="button" class="btn btn-quiet btn-small" id="view-graph" aria-pressed="${state.view === 'graph'}">Graph view</button>
        <button type="button" class="btn btn-quiet btn-small" id="view-list" aria-pressed="${state.view === 'list'}">List view (accessible)</button>
      </div>
      <div class="btn-row" id="zoom-btns"><button type="button" class="btn btn-quiet btn-small" data-zoom="1.3" aria-label="Zoom in">+</button><button type="button" class="btn btn-quiet btn-small" data-zoom="0.77" aria-label="Zoom out">−</button><button type="button" class="btn btn-quiet btn-small" id="zoom-reset">Reset view</button></div>
      <p id="net-status" role="status" style="margin:0 0 0 auto;font-size:.85rem;color:var(--text-2)"></p>
    </div>
    <div class="legend legend-compact" style="margin-bottom:.8rem"><span class="legend-title">Tiers (node colour)</span>${db.tiers.map((t) => html`<span class="item"><span class="dot" style="background:${tierColor(t.id)}" aria-hidden="true"></span>${t.label}</span>`)}
      <span class="legend-title" style="margin-top:.4rem">Edge colour = evidence grade (dashed = disputed / unverified)</span>${CONF_ORDER.map((c) => html`<span class="item">${badge(c)}</span>`)}</div>
    <div id="net-graph" class="graph-wrap" ${state.view === 'list' ? raw('hidden') : ''}></div>
    <p class="help" ${state.view === 'list' ? raw('hidden') : ''} id="net-help">Select a node for its profile summary, or a line for the evidence behind that relationship. Drag to pan, scroll or pinch to zoom.</p>
    <div id="net-list" ${state.view === 'graph' ? raw('hidden') : ''}></div>`,
  };
}

function filteredData() {
  const minRank = state.conf ? confRank(state.conf) : 9;
  const nodeOk = (e) => (!state.country || (e.countries || []).includes(state.country)) && (!state.kind || e.kind === state.kind);
  let nodes = db.entities.filter(nodeOk);
  const ids = new Set(nodes.map((n) => n.id));
  const links = db.relationships.filter((r) => ids.has(r.from) && ids.has(r.to) && db.entityById.has(r.from) && db.entityById.has(r.to) && (!state.type || r.type === state.type) && confRank(r.confidence) <= minRank);
  if (state.type || state.conf || state.country || state.kind) { const used = new Set(links.flatMap((l) => [l.from, l.to])); nodes = nodes.filter((n) => used.has(n.id) || (!state.type && !state.conf)); }
  return { nodes, links };
}

async function draw(root) {
  const { nodes, links } = filteredData();
  root.querySelector('#net-status').textContent = `${nodes.length} entities · ${links.length} relationships shown`;
  // list view
  const byTier = db.tiers.map((t) => [t, nodes.filter((n) => db.entityTiers[n.id] === t.id)]).filter(([, l]) => l.length);
  root.querySelector('#net-list').innerHTML = String(nodes.length ? html`${byTier.map(([t, list]) => html`<section class="section"><h2>${t.label} <span class="mono" style="color:var(--muted);font-size:.9rem">(${list.length})</span></h2>
    <ul>${list.map((n) => html`<li><a href="#/entity/${encodeURIComponent(n.id)}">${n.name}</a> <span class="card-meta">${KIND_LABEL[n.kind] || n.kind}</span></li>`)}</ul></section>`)}
    <section class="section"><h2>All relationships shown</h2>${relationshipTable(links, { caption: 'Relationships matching the filters' })}</section>` : empty());
  if (state.view !== 'graph') return;
  const { createGraph } = await import('../graphkit.js');
  const { openNodePanel, openEdgePanel } = await import('../netpanels.js');
  graph?.destroy();
  const nm = (id) => db.entityById.get(id)?.name || id;
  graph = await createGraph(root.querySelector('#net-graph'), {
    nodes: nodes.map((e) => ({ id: e.id, name: e.name, kind: e.kind, kindLabel: KIND_LABEL[e.kind] || e.kind, tier: db.entityTiers[e.id] ?? 4 })),
    links: links.map((r) => ({ id: r.id, source: r.from, target: r.to, type: r.type, confidence: r.confidence, sourceName: nm(r.from), targetName: nm(r.to) })),
    tiers: db.tiers,
    onNode: (id) => { graph.focus(id); openNodePanel(id); },
    onEdge: (id) => openEdgePanel(id),
  });
  if (state.focus) graph.focus(state.focus);
}

export async function mount(root) {
  const sync = () => setQuery('network', { ...state, view: state.view === 'graph' ? '' : state.view });
  const form = root.querySelector('#net-filters');
  form.addEventListener('change', (e) => { if (e.target.name) { state[e.target.name] = e.target.value; sync(); draw(root); } });
  const doSearch = () => {
    const v = root.querySelector('#net-search').value.trim().toLowerCase();
    if (!v) { state.focus = ''; graph?.clear(); sync(); return; }
    const e = db.entities.find((x) => x.name.toLowerCase() === v) || db.entities.find((x) => x.name.toLowerCase().includes(v) || (x.aliases || []).some((a) => a.toLowerCase().includes(v)));
    if (!e) { announce('No matching entity'); root.querySelector('#net-status').textContent = `No entity matches “${v}”.`; return; }
    state.focus = e.id; sync();
    if (state.view === 'graph' && graph) { if (!graph.focus(e.id)) { announce(`${e.name} is hidden by the current filters`); root.querySelector('#net-status').textContent = `${e.name} is hidden by the current filters.`; } else { announce(`Focused ${e.name}`); root.querySelector(`[data-node="${CSS.escape(e.id)}"]`)?.focus(); } }
    else location.hash = `#/entity/${encodeURIComponent(e.id)}`;
  };
  form.addEventListener('submit', (e) => { e.preventDefault(); doSearch(); });
  root.querySelector('#net-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doSearch(); } });
  root.querySelector('#net-search').addEventListener('change', doSearch);
  const setView = (v) => {
    state.view = v; sync();
    root.querySelector('#view-graph').setAttribute('aria-pressed', String(v === 'graph'));
    root.querySelector('#view-list').setAttribute('aria-pressed', String(v === 'list'));
    root.querySelector('#net-graph').hidden = v !== 'graph';
    root.querySelector('#net-help').hidden = v !== 'graph';
    root.querySelector('#zoom-btns').hidden = v !== 'graph';
    root.querySelector('#net-list').hidden = v !== 'list';
    draw(root);
  };
  root.querySelector('#view-graph').addEventListener('click', () => setView('graph'));
  root.querySelector('#view-list').addEventListener('click', () => setView('list'));
  root.querySelector('#zoom-btns').hidden = state.view !== 'graph';
  root.querySelector('#zoom-btns').addEventListener('click', (e) => { const z = e.target.closest('[data-zoom]'); if (z) graph?.zoomBy(+z.dataset.zoom); if (e.target.id === 'zoom-reset') graph?.reset(); });
  await draw(root);
}
export function unmount() { graph?.destroy(); graph = null; }
