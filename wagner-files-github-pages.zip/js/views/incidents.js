import { html, raw, badge, fmtRange, entityLink, incidentTitle, options, setQuery, debounce, toCSV, download, legend, uniq, announce, CONF_ORDER, CONF, confRank, empty } from '../ui.js';
import { countryName, yearOf, entityName } from '../data.js';

const PAGE = 100;
let state, db, shown = PAGE;

const FIELDS = ['country', 'year', 'type', 'org', 'conf', 'q', 'sort', 'dir'];

export function render(ctx) {
  db = ctx.db;
  state = Object.fromEntries(FIELDS.map((f) => [f, ctx.query.get(f) || '']));
  if (!state.sort) state.sort = 'date';
  if (!state.dir) state.dir = 'desc';
  shown = PAGE;
  const inc = db.incidents;
  const countries = uniq(inc.map((i) => i.country).filter(Boolean)).map((c) => [c, countryName(c)]).sort((a, b) => a[1].localeCompare(b[1]));
  const years = uniq(inc.map((i) => yearOf(i.date)).filter(Boolean)).sort().reverse().map((y) => [y, y]);
  const types = uniq(inc.flatMap((i) => i.types || [])).sort().map((t) => [t, t]);
  const orgs = uniq(inc.flatMap((i) => i.alleged_entities || [])).map((e) => [e, entityName(e)]).sort((a, b) => a[1].localeCompare(b[1]));
  const confs = CONF_ORDER.map((c) => [c, CONF[c].short]);
  return {
    title: 'Incident database',
    html: html`
    <header class="page-head"><p class="kicker">Incident database</p><h1 id="page-title" tabindex="-1">Incident database</h1>
    <p class="lede">Alleged and documented abuses linked to Wagner Group, Africa Corps and allied personnel. Unless graded CONFIRMED, each entry is an allegation: read the attribution basis and evidence before drawing conclusions.</p></header>
    ${legend({ compact: true })}
    <form class="filters" id="inc-filters" role="search" aria-label="Filter incidents" style="margin-top:1rem">
      <div class="f f-grow"><label for="f-q">Search text</label><input id="f-q" type="search" name="q" value="${state.q}" placeholder="Title, location, description…"></div>
      <div class="f"><label for="f-country">Country</label><select id="f-country" name="country">${options(countries, state.country, 'All countries')}</select></div>
      <div class="f"><label for="f-year">Year</label><select id="f-year" name="year">${options(years, state.year, 'All years')}</select></div>
      <div class="f"><label for="f-type">Incident type</label><select id="f-type" name="type">${options(types, state.type, 'All types')}</select></div>
      <div class="f"><label for="f-org">Organization</label><select id="f-org" name="org">${options(orgs, state.org, 'All organizations')}</select></div>
      <div class="f"><label for="f-conf">Evidence level</label><select id="f-conf" name="conf">${options(confs, state.conf, 'All levels')}</select></div>
      <div class="f"><button type="reset" class="btn btn-quiet" id="f-reset">Clear filters</button></div>
    </form>
    <div class="results-bar"><p id="inc-count" role="status" style="margin:0"></p>
      <div class="btn-row"><button type="button" class="btn btn-quiet btn-small" id="exp-csv">Export CSV</button><button type="button" class="btn btn-quiet btn-small" id="exp-json">Export JSON</button></div></div>
    <div id="inc-results"></div>`,
  };
}

function filtered() {
  const q = state.q.toLowerCase().trim();
  let list = db.incidents.filter((i) =>
    (!state.country || i.country === state.country) &&
    (!state.year || yearOf(i.date) === state.year) &&
    (!state.type || (i.types || []).includes(state.type)) &&
    (!state.org || (i.alleged_entities || []).includes(state.org)) &&
    (!state.conf || i.confidence === state.conf) &&
    (!q || [i.title, i.location, i.description, i.victims, countryName(i.country), i.id].some((v) => typeof v === 'string' && v.toLowerCase().includes(q))));
  const dir = state.dir === 'asc' ? 1 : -1;
  const key = { date: (i) => i.date || '', country: (i) => countryName(i.country), conf: (i) => confRank(i.confidence), title: (i) => i.title || '' }[state.sort] || ((i) => i.date || '');
  list.sort((a, b) => { const x = key(a), y = key(b); return (x < y ? -1 : x > y ? 1 : 0) * dir; });
  return list;
}

function th(label, key) {
  const sort = state.sort === key ? (state.dir === 'asc' ? 'ascending' : 'descending') : 'none';
  return html`<th scope="col" aria-sort="${sort}"><button type="button" class="sort-btn" data-sort="${key}">${label}</button></th>`;
}

function draw(root) {
  const list = filtered();
  root.querySelector('#inc-count').textContent = `${list.length.toLocaleString('en-US')} of ${db.incidents.length.toLocaleString('en-US')} incidents match`;
  const box = root.querySelector('#inc-results');
  if (!list.length) { box.innerHTML = String(db.incidents.length ? html`<p class="empty">No incidents match these filters.</p>` : empty()); return; }
  const rows = list.slice(0, shown);
  box.innerHTML = String(html`<div class="table-wrap cards"><table class="data responsive"><caption class="visually-hidden">Incidents matching the current filters</caption>
    <thead><tr>${th('Date', 'date')}${th('Country', 'country')}<th scope="col">Location</th>${th('Incident', 'title')}<th scope="col">Type</th><th scope="col">Alleged responsible</th>${th('Evidence', 'conf')}</tr></thead>
    <tbody>${rows.map((i) => html`<tr>
      <td class="nowrap mono" data-label="Date">${fmtRange(i.date, i.date_end)}</td>
      <td data-label="Country">${countryName(i.country)}</td>
      <td data-label="Location">${i.location || '—'}</td>
      <td data-label="Incident"><a class="row-title" href="#/incident/${encodeURIComponent(i.id)}">${incidentTitle(i)}</a></td>
      <td data-label="Type">${(i.types || []).map((t) => html`<span class="tag">${t}</span>`)}</td>
      <td data-label="Alleged responsible">${(i.alleged_entities || []).length ? i.alleged_entities.map((e, k) => html`${k ? ', ' : ''}${entityLink(e)}`) : html`<span class="empty">Not specified</span>`}</td>
      <td data-label="Evidence">${badge(i.confidence)}</td></tr>`)}</tbody></table></div>
    ${rows.length < list.length ? html`<p class="show-more"><button type="button" class="btn btn-quiet" id="show-more">Show ${Math.min(PAGE, list.length - rows.length)} more (${list.length - rows.length} remaining)</button></p>` : ''}`);
}

export function mount(root) {
  const form = root.querySelector('#inc-filters');
  const sync = () => { setQuery('incidents', { ...state, sort: state.sort === 'date' ? '' : state.sort, dir: state.dir === 'desc' ? '' : state.dir }); };
  const update = () => { shown = PAGE; sync(); draw(root); announce(root.querySelector('#inc-count').textContent); };
  form.addEventListener('change', (e) => { if (e.target.name) { state[e.target.name] = e.target.value; update(); } });
  form.querySelector('#f-q').addEventListener('input', debounce((e) => { state.q = e.target.value; update(); }, 200));
  form.addEventListener('submit', (e) => e.preventDefault());
  form.addEventListener('reset', () => { setTimeout(() => { FIELDS.forEach((f) => { if (f !== 'sort' && f !== 'dir') state[f] = ''; }); form.querySelectorAll('select').forEach((s) => (s.value = '')); update(); }, 0); });
  root.querySelector('#inc-results').addEventListener('click', (e) => {
    const s = e.target.closest('[data-sort]');
    if (s) { const k = s.dataset.sort; state.dir = state.sort === k && state.dir === 'desc' ? 'asc' : 'desc'; state.sort = k; sync(); draw(root); root.querySelector(`[data-sort="${k}"]`)?.focus(); }
    if (e.target.id === 'show-more') { shown += PAGE; draw(root); }
  });
  const cols = [
    { label: 'id', get: (i) => i.id }, { label: 'date', get: (i) => i.date }, { label: 'date_end', get: (i) => i.date_end }, { label: 'country', get: (i) => i.country }, { label: 'location', get: (i) => i.location },
    { label: 'lat', get: (i) => i.lat }, { label: 'lon', get: (i) => i.lon }, { label: 'types', get: (i) => i.types }, { label: 'title', get: (i) => i.title }, { label: 'description', get: (i) => i.description },
    { label: 'alleged_entities', get: (i) => i.alleged_entities }, { label: 'victims', get: (i) => i.victims }, { label: 'evidence', get: (i) => i.evidence }, { label: 'attribution_basis', get: (i) => i.attribution_basis },
    { label: 'independent_corroboration', get: (i) => i.independent_corroboration }, { label: 'investigation', get: (i) => i.investigation }, { label: 'legal_status', get: (i) => i.legal_status }, { label: 'confidence', get: (i) => i.confidence },
    { label: 'source_ids', get: (i) => i.source_ids }, { label: 'source_urls', get: (i) => (i.source_ids || []).map((s) => db.sourceById.get(s)?.url || s) },
  ];
  root.querySelector('#exp-csv').addEventListener('click', () => download('wagner-files-incidents.csv', toCSV(filtered(), cols), 'text/csv'));
  root.querySelector('#exp-json').addEventListener('click', () => download('wagner-files-incidents.json', JSON.stringify(filtered().map(({ _file, ...r }) => r), null, 2)));
  draw(root);
}
