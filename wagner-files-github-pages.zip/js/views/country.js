import { html, statusChip, claimList, claimItem, entityLink, reportLink, empty, fmtDate, badge, cites, plural, isEmpty } from '../ui.js';
import { incidentTable, sanctionsTable, timelineList, sourceIdsOf, sourceListing, correctionsFor } from '../components.js';

export function render({ db, params }) {
  const c = db.countryByIso.get(params[0]);
  if (!c) return null;
  const incidents = db.incidentsByCountry.get(c.iso3) || [];
  const orgs = [...new Set([...(c.entities_present || [])])];
  const companies = c.companies || [];
  const countryEntities = db.entities.filter((e) => (e.countries || []).includes(c.iso3)).map((e) => e.id);
  const sanctionTargets = new Set([...companies, ...countryEntities]);
  const sanctions = db.sanctions.filter((s) => sanctionTargets.has(s.target_entity));
  const tlCountry = (c.timeline || []).map((t, i) => ({ ...t, id: null, _k: i }));
  const tlGlobal = db.timelineByCountry.get(c.iso3) || [];
  const allSources = sourceIdsOf(c);
  incidents.forEach((i) => (i.source_ids || []).forEach((s) => allSources.add(s)));
  tlGlobal.forEach((t) => (t.source_ids || []).forEach((s) => allSources.add(s)));
  const sec = (id, title, body) => html`<section class="section" id="${id}" aria-labelledby="${id}-h"><h2 id="${id}-h">${title}</h2>${body}</section>`;
  const toc = [['c-involvement', 'Nature of involvement'], ['c-gov', 'Government relationships'], ['c-orgs', 'Organizations present'], ['c-timeline', 'Timeline'], ['c-incidents', 'Incidents'], ['c-econ', 'Economic interests'], ['c-info', 'Information operations'], ['c-abuses', 'Abuses (summary)'], ['c-sanctions', 'Sanctions'], ['c-status', 'Current status'], ['c-sources', 'Sources']];
  return {
    title: c.name,
    html: html`
    <p><a class="back-link" href="#/${c.region === 'Africa' ? 'africa' : 'map'}">← ${c.region === 'Africa' ? 'Africa' : 'Global map'}</a></p>
    <header class="page-head"><p class="kicker">Country profile · ${c.region || 'Region not recorded'}</p><h1 id="page-title" tabindex="-1">${c.name}</h1>
    <div class="meta-line">${statusChip(c.status)}<span>${plural(incidents.length, 'incident')}</span><span>${plural(orgs.length + companies.length, 'linked organization')}</span><span class="id-line">${c.iso3}</span>${reportLink(c.iso3)}</div></header>
    <div class="two-col"><div>
    ${sec('c-involvement', 'Nature of involvement', html`<h3>Entry</h3>${claimList(c.entry)}<h3>Mission</h3>${claimList(c.mission)}<h3>Presence estimates</h3>${claimList(c.presence_estimate)}`)}
    ${sec('c-gov', 'Government relationships', html`<h3>Relationship with host authorities</h3>${claimList(c.host_relationship)}<h3>Political influence</h3>${claimList(c.political_influence)}`)}
    ${sec('c-orgs', 'Organizations present', html`<h3>Russian-linked forces and organizations</h3>${orgs.length ? html`<ul>${orgs.map((o) => html`<li>${entityLink(o)}</li>`)}</ul>` : empty()}<h3>Companies</h3>${companies.length ? html`<ul>${companies.map((o) => html`<li>${entityLink(o)}</li>`)}</ul>` : empty()}`)}
    ${sec('c-timeline', 'Timeline', html`${timelineList([...tlCountry, ...tlGlobal], { showCountry: false, idPrefix: 'ctl' })}`)}
    ${sec('c-incidents', 'Incidents', html`${incidentTable(incidents, { caption: `Incidents recorded in ${c.name}`, showCountry: false, limit: 50 })}${incidents.length ? html`<p><a href="#/incidents?country=${c.iso3}">Filter the incident database to ${c.name} →</a></p>` : ''}`)}
    ${sec('c-econ', 'Economic interests', claimList(c.economic_interests))}
    ${sec('c-info', 'Information operations', claimList(c.information_operations))}
    ${sec('c-abuses', 'Abuses (summary)', claimList(c.abuses_summary))}
    ${sec('c-sanctions', 'Sanctions', html`${claimList(c.sanctions_summary)}<h3>Designations of linked entities</h3>${sanctionsTable(sanctions, { caption: `Designations of entities linked to ${c.name}` })}`)}
    ${sec('c-status', 'Current status', claimList(c.current_status))}
    ${sec('c-sources', 'Sources', sourceListing(allSources))}
    ${correctionsFor(c.iso3)}
    </div>
    <nav class="toc" aria-label="On this page"><p class="kicker">On this page</p><ol>${toc.map(([id, t]) => html`<li><a href="#/country/${c.iso3}" data-scroll-to="${id}">${t}</a></li>`)}</ol></nav>
    </div>`,
  };
}
