import { correctionsFor } from '../components.js';
import { html, incidentTitle, SRC_CAT, fmtDate, badge, reportLink, empty, field, plural } from '../ui.js';

export const PAGE_ROUTE = { history: '#/ukraine', ukraine: '#/ukraine', 'prison-recruitment': '#/ukraine', casualties: '#/ukraine', rebellion: '#/ukraine', 'prigozhin-crash': '#/ukraine', transition: '#/africa', money: '#/money', 'sanctions-evasion': '#/money', 'executive-summary': '#/summary', 'methodology-notes': '#/methodology' };
const KIND = { incident: 'Incidents', entity: 'People & organization profiles', relationship: 'Network relationships', sanction: 'Sanctions designations', country: 'Country profiles', timeline: 'Timeline events', page: 'Long-form sections', finding: 'Best-documented findings', unproven: 'What remains unproven' };
export function render({ db, params }) {
  const s = db.sourceById.get(params[0]);
  if (!s) return null;
  const links = db.backlinks[s.id] || [];
  const href = (b) => ({ incident: `#/incident/${encodeURIComponent(b.id)}`, entity: `#/entity/${encodeURIComponent(b.id)}`, sanction: b.target ? `#/entity/${encodeURIComponent(b.target)}` : '#/sanctions', country: `#/country/${b.id}`, timeline: `#/timeline?focus=${encodeURIComponent(b.id)}`, page: PAGE_ROUTE[b.section] || (b.section === 'accountability' ? '#/ukraine' : `#/section/${b.section}`), finding: '#/findings', unproven: '#/findings', relationship: null }[b.kind]);
  const groups = Object.keys(KIND).map((k) => [k, links.filter((b) => b.kind === k)]).filter(([, l]) => l.length);
  const link = (u) => (u ? html`<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>` : '');
  return {
    title: s.title,
    html: html`
    <p><a class="back-link" href="#/library">← Document library</a></p>
    <header class="page-head"><p class="kicker">Source · ${SRC_CAT[s.category] || s.category || 'Uncategorised'}${s.primary === true ? ' · primary' : s.primary === false ? ' · secondary' : ''}</p><h1 id="page-title" tabindex="-1">${s.title}</h1>
    <div class="meta-line"><span>${s.publisher || ''}</span><span>${fmtDate(s.date)}</span><span class="id-line">${s.id}</span>${reportLink(s.id)}</div></header>
    ${s.category === 'party-statement' ? html`<p class="note-box">Party statement: this source records what a party claimed. It is not independent verification of the underlying facts.</p>` : ''}
    <dl class="fields">
      ${field('Source', s.title)}${field('Publication', s.publisher)}${s.author ? field('Author', s.author) : ''}${field('Date', fmtDate(s.date))}
      ${field('URL', link(s.url))}${field('Archived URL', s.archive_url ? link(s.archive_url) : html`<span class="empty">No archived copy recorded.</span>`)}
      ${field('Summary', s.summary)}${field('Relevant evidence', s.key_evidence)}${field('Access date', fmtDate(s.access_date))}
    </dl>
    <section class="section" aria-labelledby="h-bl"><h2 id="h-bl">Cited by (${links.length})</h2>
    ${groups.length ? groups.map(([k, list]) => html`<h3>${KIND[k]} <span class="mono" style="color:var(--muted);font-size:.85rem">(${list.length})</span></h3><ul class="backlinks">${list.map((b) => html`<li>${b.confidence ? html`${badge(b.confidence)} ` : ''}${k === 'relationship' ? html`<button type="button" class="btn btn-quiet btn-small" data-edge="${b.id}">${b.label}</button>` : html`<a href="${href(b)}">${k === 'incident' && db.incidentById.has(b.id) ? incidentTitle(db.incidentById.get(b.id)) : b.label || b.id}</a>`}${b.where ? html` <span class="card-meta">— ${b.where}</span>` : ''}${b.text ? html`<div class="card-meta" style="font-family:var(--serif);font-size:.92rem">“${b.text}”</div>` : ''}</li>`)}</ul>`) : empty()}
    </section>
    ${correctionsFor(s.id)}`,
  };
}
export function mount(root) {
  root.querySelectorAll('[data-edge]').forEach((b) => b.addEventListener('click', async () => { const { openEdgePanel } = await import('../netpanels.js'); openEdgePanel(b.dataset.edge); }));
}
