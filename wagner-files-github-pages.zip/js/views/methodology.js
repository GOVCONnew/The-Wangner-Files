import { html, legend, renderPages, fmtDate, CONF, CONF_ORDER, badge, SRC_CAT, SRC_CAT_ORDER } from '../ui.js';
import { pagesFor } from '../data.js';

export function render({ db }) {
  const notes = pagesFor('methodology-notes');
  const sections = [['m-principle', 'Core principle'], ['m-sources', 'Source selection'], ['m-grading', 'Evidence grading'], ['m-conflict', 'Conflicting accounts'], ['m-allegations', 'Allegations versus findings'], ['m-sanctions', 'Reading sanctions designations'], ['m-osint', 'Limitations of open-source research'], ['m-privacy', 'Privacy'], ['m-corrections', 'Corrections policy'], ['m-updated', 'Last updated'], ['m-notes', 'Research notes']];
  return {
    title: 'Methodology',
    html: html`
    <header class="page-head"><p class="kicker">Methodology</p><h1 id="page-title" tabindex="-1">How this database is built</h1>
    <p class="lede">What we include, how we grade it, and what open-source research cannot tell you.</p></header>
    <div class="two-col"><div class="prose">
    <section class="section" id="m-principle"><h2>Core principle</h2>
      <p class="principle">Absence from this database does not imply innocence or guilt.</p>
      <p>This is an accountability record, not propaganda. An accusation is never treated as true because it is damaging. Every statement is recorded as a discrete claim with an evidence grade and the sources it rests on, so readers can check each one.</p></section>
    <section class="section" id="m-sources"><h2>Source selection</h2>
      <p>Sources fall into these categories, shown separately in the <a href="#/library">document library</a>:</p>
      <ul>${SRC_CAT_ORDER.map((c) => html`<li>${SRC_CAT[c]}</li>`)}</ul>
      <p>Each source records its publisher, date, URL, an archived copy where one could be confirmed, the date it was accessed, whether it is a primary source, and the specific passage relied on. Only URLs that researchers actually opened are recorded. Secondary reporting is traced back to its original evidence where possible. Confidence is never raised just because several outlets repeated the same original source.</p>
      <p>Statements by the Russian, Ukrainian and African governments, and by Wagner, the Africa Corps or their leaders, are recorded as <strong>party claims</strong>. They show what a party said. They are never independent verification.</p></section>
    <section class="section" id="m-grading"><h2>Evidence grading</h2>
      <p>Every claim, incident, relationship, timeline event and finding carries one of five grades, shown as a coloured badge with a text label:</p>
      <dl class="fields">${CONF_ORDER.map((c) => html`<dt>${badge(c)}</dt><dd>${CONF[c].desc}</dd>`)}</dl>
      <p><strong>Independent</strong> means separate original evidence, not separate outlets repeating one report. A party’s own statement alone can never make a claim CONFIRMED. Bracketed numbers such as [1] after each statement open the source it relies on.</p></section>
    <section class="section" id="m-conflict"><h2>Conflicting accounts</h2>
      <p>Where credible sources disagree, or a party denies an allegation and offers some supporting evidence, the claim is graded DISPUTED and the competing accounts are cited side by side. Numerical estimates, such as casualty figures, are shown as tables listing each estimate, who made it, when, the method used and its caveats. The database never picks a single “true” number.</p></section>
    <section class="section" id="m-allegations"><h2>Allegations versus findings</h2>
      <p>An incident graded anything other than CONFIRMED is presented as an <em>allegation</em>: its title is prefixed “Alleged”, and its record separates the evidence, the basis for attributing it to Russian, Wagner or Africa Corps personnel rather than local allied forces, independent corroboration, and the status of any investigation. Being named in an allegation is not a finding of responsibility.</p></section>
    <section class="section" id="m-sanctions"><h2>Reading sanctions designations</h2>
      <p>A designation by OFAC, the EU, the UK or another authority confirms that the authority made the designation and what basis it stated. The conduct itself is described “according to” that authority, and is graded on the evidence like any other claim.</p></section>
    <section class="section" id="m-osint"><h2>Limitations of open-source research</h2>
      <ul>
        <li>Deployments are deliberately deniable. Much of the record rests on leaks, defectors, intercepted communications reported by the media, and official statements from interested parties.</li>
        <li>Access to conflict zones is restricted. Many incidents in Africa and Ukraine cannot be independently visited, and witnesses may face reprisals.</li>
        <li>Video and imagery can be misdated, misattributed or manipulated. Geolocation and chronolocation reduce this risk but do not remove it.</li>
        <li>Attribution between Russian personnel and local allied forces operating together is often uncertain. That uncertainty is recorded explicitly for each incident.</li>
        <li>Corporate registries in many jurisdictions are opaque. Ownership links may be inferred from sanctions findings or leaked documents rather than primary filings.</li>
        <li>Online sources disappear. Archived copies are recorded where they could be confirmed.</li>
        <li>Coverage is uneven: better-reported countries and periods will appear to have more incidents. Counts in this database are not measures of the true scale of abuses.</li>
      </ul></section>
    <section class="section" id="m-privacy"><h2>Privacy</h2><p>Only public figures and organizations are profiled. No personal information about private individuals (home addresses, phone numbers, family details) is published.</p></section>
    <section class="section" id="m-corrections"><h2>Corrections policy</h2>
      <p>Errors are corrected promptly and transparently. Every record has a “Report an error” link that opens a <a href="#/corrections">structured correction form</a> pre-filled with that record’s identifier. Corrections that change a grade, attribution or figure are listed in the public corrections log with the date and a description of the change. Grades may go down as well as up as evidence emerges.</p></section>
    <section class="section" id="m-updated"><h2>Last updated</h2>
      <p>Data last updated: <strong>${fmtDate(db.meta.last_updated)}</strong>.${db.meta.latest_access_date ? html` Most recent source access date: ${fmtDate(db.meta.latest_access_date)}.` : ''} Database schema ${db.meta.schema}.</p></section>
    <section class="section" id="m-notes"><h2>Research notes</h2><div style="font-family:var(--sans)">${renderPages(notes, { idPrefix: 'mn' })}</div></section>
    </div>
    <nav class="toc" aria-label="On this page"><p class="kicker">On this page</p><ol>${sections.map(([id, t]) => html`<li><a href="#/methodology" data-scroll-to="${id}">${t}</a></li>`)}</ol></nav></div>
    <div style="margin-top:2rem">${legend()}</div>`,
  };
}
