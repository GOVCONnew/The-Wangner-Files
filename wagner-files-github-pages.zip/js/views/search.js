import { html, badge, fmtDate, debounce, incidentTitle, empty, KIND_LABEL, SRC_CAT, TL_CAT_LABEL, STATUS } from '../ui.js';
import { countryName } from '../data.js';

let index = null, docsById = null, db;
const TYPES = [['incident', 'Incidents'], ['entity', 'People & organizations'], ['country', 'Countries'], ['sanction', 'Sanctions'], ['timeline', 'Timeline'], ['source', 'Sources']];

async function buildIndex() {
  if (index) return index;
  const { default: MiniSearch } = await import('../../vendor/minisearch/index.js');
  const docs = [
    ...db.incidents.map((i) => ({ id: `incident:${i.id}`, type: 'incident', title: incidentTitle(i), text: [i.description, i.location, countryName(i.country), (i.types || []).join(' ')].join(' '), url: `#/incident/${encodeURIComponent(i.id)}`, meta: `${fmtDate(i.date)} · ${countryName(i.country)}`, conf: i.confidence })),
    ...db.entities.map((e) => ({ id: `entity:${e.id}`, type: 'entity', title: e.name, text: [(e.aliases || []).join(' '), e.role, e.summary].join(' '), url: `#/entity/${encodeURIComponent(e.id)}`, meta: `${KIND_LABEL[e.kind] || e.kind}${e.role ? ' · ' + e.role : ''}` })),
    ...db.countries.map((c) => ({ id: `country:${c.iso3}`, type: 'country', title: c.name, text: `${c.iso3} ${c.region || ''}`, url: `#/country/${c.iso3}`, meta: STATUS[c.status]?.label || c.status })),
    ...db.sanctions.map((s) => ({ id: `sanction:${s.id}`, type: 'sanction', title: s.name_as_listed || s.target_entity, text: [s.program, s.reason, s.authority, s.jurisdiction].join(' '), url: db.entityById.has(s.target_entity) ? `#/entity/${encodeURIComponent(s.target_entity)}` : `#/sanctions?q=${encodeURIComponent(s.name_as_listed || '')}`, meta: `${s.authority} · ${fmtDate(s.date)}${s.program ? ' · ' + s.program : ''}` })),
    ...db.timeline.map((t) => ({ id: `timeline:${t.id}`, type: 'timeline', title: t.title, text: t.text, url: `#/timeline?focus=${encodeURIComponent(t.id)}`, meta: `${fmtDate(t.date)} · ${TL_CAT_LABEL[t.category] || t.category || ''}`, conf: t.confidence })),
    ...db.sources.map((s) => ({ id: `source:${s.id}`, type: 'source', title: s.title, text: [s.publisher, s.author, s.summary].join(' '), url: `#/source/${encodeURIComponent(s.id)}`, meta: `${s.publisher || ''} · ${fmtDate(s.date)} · ${SRC_CAT[s.category] || s.category || ''}` })),
  ];
  docsById = new Map(docs.map((d) => [d.id, d]));
  index = new MiniSearch({ fields: ['title', 'text'], storeFields: ['type'], searchOptions: { boost: { title: 3 }, prefix: true, fuzzy: 0.15, combineWith: 'AND' } });
  index.addAll(docs);
  return index;
}

export function render(ctx) {
  db = ctx.db;
  const q = ctx.query.get('q') || '';
  return {
    title: q ? `Search: ${q}` : 'Search',
    html: html`<header class="page-head"><p class="kicker">Search</p><h1 id="page-title" tabindex="-1">Search the database</h1><p class="lede">Incidents, people and organizations, countries, sanctions, timeline events and sources.</p></header>
    <form class="search-big" role="search" id="big-search" aria-label="Search this page"><label class="visually-hidden" for="big-q">Search terms</label><input id="big-q" type="search" name="q" value="${q}" placeholder="e.g. a place, a company, a program…" autocomplete="off"><button class="btn" type="submit">Search</button></form>
    <p id="search-count" role="status"></p><div id="search-results"></div>`,
  };
}
async function run(root, q) {
  const box = root.querySelector('#search-results');
  const status = root.querySelector('#search-count');
  if (!q.trim()) { status.textContent = ''; box.innerHTML = ''; return; }
  const idx = await buildIndex();
  let res = idx.search(q);
  if (!res.length) res = idx.search(q, { combineWith: 'OR' });
  status.textContent = `${res.length} result${res.length === 1 ? '' : 's'} for “${q}”`;
  if (!res.length) { box.innerHTML = String(html`<p class="empty">No results. Try fewer or different words.</p>`); return; }
  const groups = TYPES.map(([t, l]) => [l, res.filter((r) => r.type === t).slice(0, 25), res.filter((r) => r.type === t).length]).filter(([, l]) => l.length);
  box.innerHTML = String(groups.map(([l, list, n]) => html`<section class="section result-group"><h2>${l} <span class="mono" style="color:var(--muted)">(${n})</span></h2>${list.map((r) => { const d = docsById.get(r.id); return html`<div class="result-item"><a href="${d.url}"><strong>${d.title}</strong></a> ${d.conf ? badge(d.conf) : ''}<div class="r-meta">${d.meta}</div></div>`; })}${n > list.length ? html`<p class="help">Showing the top ${list.length} of ${n}.</p>` : ''}</section>`));
}
export async function mount(root, ctx) {
  const input = root.querySelector('#big-q');
  const go = debounce(() => { const q = input.value; history.replaceState(null, '', `${location.pathname}${location.search}#/search${q ? '?q=' + encodeURIComponent(q) : ''}`); run(root, q); }, 180);
  input.addEventListener('input', go);
  root.querySelector('#big-search').addEventListener('submit', (e) => { e.preventDefault(); go(); });
  document.getElementById('header-search-input').value = ctx.query.get('q') || '';
  await run(root, ctx.query.get('q') || '');
}
