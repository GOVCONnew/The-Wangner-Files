// Tiered force-directed network (D3). The layout is pre-computed (no continuous
// animation); dragging nudges it. Nodes are keyboard-focusable.
import { esc } from './lib/html.js';
import { CONF_COLOR } from './confcolors.js';

let d3p = null;
export function loadD3() {
  if (window.d3) return Promise.resolve(window.d3);
  return (d3p ||= new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'vendor/d3/d3.min.js'; s.onload = () => res(window.d3); s.onerror = rej; document.head.appendChild(s); }));
}
const TIER_COLOR = ['#e8e4da', '#c9a26b', '#d2463c', '#e6a07a', '#8fa9b8', '#7fb0a0', '#c7b85e', '#9b8fc9', '#a88f7a', '#8a8f96'];
export const tierColor = (t) => TIER_COLOR[t] ?? '#8a8f96';

export async function createGraph(container, { nodes, links, tiers, onNode, onEdge, labelAll = null }) {
  const d3 = await loadD3();
  container.innerHTML = '';
  const width = Math.max(container.clientWidth, 320);
  const svg = d3.select(container).append('svg').attr('role', 'group').attr('aria-label', `Network graph with ${nodes.length} entities and ${links.length} relationships. Use Tab to move between entities and Enter to open details; the list view offers the same information.`);
  const viewH = svg.node().getBoundingClientRect().height || 640;
  svg.attr('viewBox', `0 0 ${width} ${viewH}`);
  // lay out in a virtual canvas at least 900px wide, then scale to fit narrow screens
  const k0 = Math.min(1, width / 900);
  const W = width / k0, height = viewH / k0;
  const present = [...new Set(nodes.map((n) => n.tier))].sort((a, b) => a - b);
  const band = (height - 60) / Math.max(present.length, 1);
  const yOf = new Map(present.map((t, i) => [t, 40 + band * i + band / 2]));
  const deg = new Map(nodes.map((n) => [n.id, 0]));
  links.forEach((l) => { deg.set(l.source, (deg.get(l.source) || 0) + 1); deg.set(l.target, (deg.get(l.target) || 0) + 1); });
  const N = nodes.map((n) => ({ ...n, r: 5 + Math.sqrt(deg.get(n.id) || 0) * 2.2, x: W / 2 + (Math.random() - 0.5) * W * 0.6, y: yOf.get(n.tier) }));
  const L = links.map((l) => ({ ...l }));
  const sim = d3.forceSimulation(N)
    .force('link', d3.forceLink(L).id((d) => d.id).distance(80).strength(0.08))
    .force('charge', d3.forceManyBody().strength(-240).distanceMax(400))
    .force('x', d3.forceX(W / 2).strength(0.03))
    .force('y', d3.forceY((d) => yOf.get(d.tier)).strength(0.7))
    .force('collide', d3.forceCollide((d) => d.r + 7).iterations(2))
    .stop();
  for (let i = 0; i < 360; i++) sim.tick();
  N.forEach((n) => { n.x = Math.max(24, Math.min(W - 24, n.x)); const y0 = yOf.get(n.tier); n.y = Math.max(y0 - band * 0.38, Math.min(y0 + band * 0.38, n.y)); });
  // greedy label placement: highest-degree nodes first, skip labels that would collide
  const placed = present.map((t) => [0, yOf.get(t) - band / 2, 250 / k0, yOf.get(t) - band / 2 + 20 / k0]); // reserve tier-label boxes
  const overlaps = (box, n) => placed.some((b) => box[0] < b[2] && box[2] > b[0] && box[1] < b[3] && box[3] > b[1]) || N.some((m) => m !== n && m.x + m.r > box[0] && m.x - m.r < box[2] && Math.abs(m.y - n.y) < m.r + 7);
  [...N].sort((a, b) => (deg.get(b.id) || 0) - (deg.get(a.id) || 0) || a.tier - b.tier).forEach((n) => {
    const w = Math.min(n.name.length * 5.4, 170);
    const right = [n.x + n.r + 3, n.y - 8, n.x + n.r + 5 + w, n.y + 8];
    const left = [n.x - n.r - 5 - w, n.y - 8, n.x - n.r - 3, n.y + 8];
    if (!overlaps(right, n) && right[2] < W) { n.labelSide = 'right'; placed.push(right); }
    else if (!overlaps(left, n) && left[0] > 150) { n.labelSide = 'left'; placed.push(left); }
    else n.labelSide = labelAll === true ? 'right' : null;
  });

  const root = svg.append('g');
  const bands = root.append('g');
  const labelsLater = [];
  present.forEach((t) => {
    const y = yOf.get(t);
    bands.append('line').attr('class', 'tier-line').attr('x1', -2000).attr('x2', W + 2000).attr('y1', y - band / 2).attr('y2', y - band / 2);
    labelsLater.push(() => tierLabels.append('text').attr('class', 'tier-label').attr('x', 8).attr('y', y - band / 2 + 14 / k0).style('font-size', `${Math.min(10 / k0, 24)}px`).text(tiers.find((x) => x.id === t)?.label || `Tier ${t}`));
  });
  const defs = svg.append('defs');
  Object.entries(CONF_COLOR).forEach(([c, col]) => defs.append('marker').attr('id', `arrow-${c}`).attr('viewBox', '0 -4 8 8').attr('refX', 8).attr('refY', 0).attr('markerWidth', 6).attr('markerHeight', 6).attr('orient', 'auto').append('path').attr('d', 'M0,-4L8,0L0,4').attr('fill', col));
  const linkG = root.append('g');
  const edge = linkG.selectAll('g').data(L).join('g').attr('class', 'edge');
  const hit = edge.append('line').attr('class', 'link-hit').attr('data-rel', (d) => d.id);
  const line = edge.append('line').attr('class', 'link').attr('stroke', (d) => CONF_COLOR[d.confidence] || '#888').attr('stroke-width', 1.4)
    .attr('stroke-dasharray', (d) => (d.confidence === 'disputed' || d.confidence === 'unverified' ? '4 3' : null)).attr('marker-end', (d) => `url(#arrow-${CONF_COLOR[d.confidence] ? d.confidence : 'unverified'})`);
  hit.append('title').text((d) => `${d.sourceName} → ${d.type} → ${d.targetName} (${d.confidence})`);
  hit.on('click', (ev, d) => onEdge?.(d.id));
  const node = root.append('g').selectAll('g').data(N).join('g').attr('class', 'node').attr('tabindex', 0).attr('role', 'button').attr('data-node', (d) => d.id)
    .attr('aria-label', (d) => `${d.name}, ${d.kindLabel}, ${tiers.find((x) => x.id === d.tier)?.label || ''}, ${deg.get(d.id) || 0} relationships`);
  node.append('circle').attr('r', (d) => d.r).attr('fill', (d) => tierColor(d.tier));
  node.append('title').text((d) => d.name);
  node.append('text').attr('x', (d) => (d.labelSide === 'left' ? -(d.r + 4) : d.r + 4)).attr('text-anchor', (d) => (d.labelSide === 'left' ? 'end' : 'start')).attr('y', 3.5).attr('class', (d) => (d.labelSide ? 'on' : 'off')).text((d) => d.name);
  const tierLabels = root.append('g');
  labelsLater.forEach((f) => f());
  node.on('click', (ev, d) => { ev.stopPropagation(); onNode?.(d.id); });
  node.on('keydown', (ev, d) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); onNode?.(d.id); } });
  const pos = () => {
    const ends = (d) => { const dx = d.target.x - d.source.x, dy = d.target.y - d.source.y, len = Math.hypot(dx, dy) || 1; return [d.source.x, d.source.y, d.target.x - (dx / len) * (d.target.r + 2), d.target.y - (dy / len) * (d.target.r + 2)]; };
    [line, hit].forEach((s) => s.each(function (d) { const [x1, y1, x2, y2] = ends(d); this.setAttribute('x1', x1); this.setAttribute('y1', y1); this.setAttribute('x2', x2); this.setAttribute('y2', y2); }));
    node.attr('transform', (d) => `translate(${d.x},${d.y})`);
  };
  pos();
  node.call(d3.drag().on('start', (ev, d) => { d.fx = d.x; d.fy = d.y; }).on('drag', (ev, d) => { d.x = d.fx = ev.x; d.y = d.fy = ev.y; pos(); }).on('end', (ev, d) => { d.fx = null; d.fy = null; }));
  const zoom = d3.zoom().scaleExtent([Math.min(0.3, k0 * 0.8), 5]).on('zoom', (ev) => root.attr('transform', ev.transform));
  const initial = d3.zoomIdentity.scale(k0);
  svg.call(zoom).on('dblclick.zoom', null);
  svg.call(zoom.transform, initial);
  const neighbors = (id) => { const s = new Set([id]); L.forEach((l) => { if (l.source.id === id) s.add(l.target.id); if (l.target.id === id) s.add(l.source.id); }); return s; };
  return {
    focus(id) {
      const n = N.find((x) => x.id === id);
      if (!n) return false;
      const nb = neighbors(id);
      node.classed('dim', (d) => !nb.has(d.id)).classed('hl', (d) => d.id === id).classed('nb', (d) => nb.has(d.id));
      edge.classed('dim', (d) => d.source.id !== id && d.target.id !== id);
      line.classed('hl', (d) => d.source.id === id || d.target.id === id);
      const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
      const t = d3.zoomIdentity.translate(width / 2, viewH / 2).scale(Math.max(1.3, k0 * 1.6)).translate(-n.x, -n.y);
      (reduce ? svg : svg.transition().duration(400)).call(zoom.transform, t);
      return true;
    },
    clear() { node.classed('dim', false).classed('hl', false).classed('nb', false); edge.classed('dim', false); line.classed('hl', false); },
    reset() { this.clear(); svg.call(zoom.transform, initial); },
    zoomBy(k) { svg.call(zoom.scaleBy, k); },
    destroy() { sim.stop(); container.innerHTML = ''; },
  };
}
