// Side-panel content for graph node (entity) and edge (relationship) clicks.
import { html, badge, CONF, REL_LABEL, KIND_LABEL, fmtDate, reportLink, empty, claimList } from './ui.js';
import { db } from './data.js';
import { openPanel } from './panel.js';

export const sourceButtons = (ids = []) => (ids.length ? html`<ul class="src-list">${ids.map((id) => { const s = db.sourceById.get(id); return html`<li class="src-item"><button type="button" class="btn btn-quiet btn-small" data-src="${id}" data-open-source>${s ? s.title : id + ' (missing)'}</button>${s ? html`<div class="src-meta">${s.publisher || ''}${s.date ? ' · ' + fmtDate(s.date) : ''}</div>` : ''}</li>`; })}</ul>` : empty());

export function openEdgePanel(relId) {
  const r = db.relById.get(relId);
  if (!r) return;
  const nm = (id) => db.entityById.get(id)?.name || id;
  openPanel({
    kicker: 'Relationship evidence',
    title: `${nm(r.from)} → ${REL_LABEL[r.type] || r.type} → ${nm(r.to)}`,
    body: html`<dl class="fields">
      <dt>From</dt><dd><a href="#/entity/${encodeURIComponent(r.from)}">${nm(r.from)}</a></dd>
      <dt>Relationship</dt><dd>${REL_LABEL[r.type] || r.type}</dd>
      <dt>To</dt><dd><a href="#/entity/${encodeURIComponent(r.to)}">${nm(r.to)}</a></dd>
      <dt>Description</dt><dd>${r.description || empty()}</dd>
      <dt>Period</dt><dd>${r.period || empty()}</dd>
      <dt>Confidence</dt><dd>${badge(r.confidence)}<div class="help" style="margin-top:.3rem">${CONF[r.confidence]?.desc || ''}</div></dd>
    </dl><h3 style="margin-top:1.2rem">Sources</h3>${sourceButtons(r.source_ids)}
    <div class="panel-actions">${reportLink(r.id)}</div>`,
  });
}

export function openNodePanel(entId) {
  const e = db.entityById.get(entId);
  if (!e) return;
  const rels = db.relsByEntity.get(entId) || [];
  const tier = db.tiers.find((t) => t.id === db.entityTiers[entId]);
  openPanel({
    kicker: `${KIND_LABEL[e.kind] || e.kind} · ${tier?.label || ''}`,
    title: e.name,
    body: html`${e.role ? html`<p><strong>${e.role}</strong></p>` : ''}<p style="font-family:var(--serif)">${e.summary || empty()}</p>
    <h3>Relationships (${rels.length})</h3>
    ${rels.length ? html`<ul class="src-list">${rels.map((r) => { const other = r.from === entId ? r.to : r.from; const dir = r.from === entId ? `${REL_LABEL[r.type] || r.type} →` : `← ${REL_LABEL[r.type] || r.type}`; return html`<li class="src-item">${badge(r.confidence)} <span class="tag">${dir}</span> <a href="#/entity/${encodeURIComponent(other)}">${db.entityById.get(other)?.name || other}</a> <button type="button" class="btn btn-quiet btn-small" data-edge="${r.id}">Evidence</button></li>`; })}</ul>` : empty()}
    <div class="panel-actions"><a class="btn" href="#/entity/${encodeURIComponent(entId)}">Open full profile →</a>${reportLink(entId)}</div>`,
  });
  document.querySelectorAll('#panel-root [data-edge]').forEach((b) => b.addEventListener('click', () => openEdgePanel(b.dataset.edge)));
}
