// Shared composite components used by several views.
import { html, raw, esc, badge, cites, fmtDate, fmtRange, entityLink, countryLink, incidentTitle, empty, REL_LABEL, TL_CAT_LABEL, confRank, isEmpty } from './ui.js';
import { db, countryName } from './data.js';

export function incidentTable(list, { caption = 'Incidents', showCountry = true, limit = Infinity } = {}) {
  if (!list.length) return empty();
  const rows = [...list].sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))).slice(0, limit);
  return html`<div class="table-wrap cards"><table class="data responsive"><caption>${caption} (${list.length})</caption>
  <thead><tr><th scope="col">Date</th>${showCountry ? html`<th scope="col">Country</th>` : ''}<th scope="col">Incident</th><th scope="col">Type</th><th scope="col">Alleged responsible</th><th scope="col">Evidence grade</th></tr></thead>
  <tbody>${rows.map((i) => html`<tr>
    <td class="nowrap mono" data-label="Date">${fmtRange(i.date, i.date_end)}</td>
    ${showCountry ? html`<td data-label="Country">${countryName(i.country)}</td>` : ''}
    <td data-label="Incident"><a class="row-title" href="#/incident/${encodeURIComponent(i.id)}">${incidentTitle(i)}</a>${i.location ? html`<div class="card-meta">${i.location}</div>` : ''}</td>
    <td data-label="Type">${(i.types || []).map((t) => html`<span class="tag">${t}</span>`)}</td>
    <td data-label="Alleged responsible">${(i.alleged_entities || []).length ? (i.alleged_entities || []).map((e, k) => html`${k ? ', ' : ''}${entityLink(e)}`) : html`<span class="empty">Not specified</span>`}</td>
    <td data-label="Evidence grade">${badge(i.confidence)}</td></tr>`)}</tbody></table></div>
  ${rows.length < list.length ? html`<p class="help">Showing ${rows.length} of ${list.length}. <a href="#/incidents">Open the full incident database</a>.</p>` : ''}`;
}

export function sanctionsTable(list, { caption = 'Sanctions designations' } = {}) {
  if (!list.length) return empty();
  const rows = [...list].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
  return html`<div class="table-wrap cards"><table class="data responsive"><caption>${caption} (${list.length})</caption>
  <thead><tr><th scope="col">Listed as</th><th scope="col">Authority</th><th scope="col">Program</th><th scope="col">Date</th><th scope="col">Stated reason</th><th scope="col">Official source</th></tr></thead>
  <tbody>${rows.map((s) => html`<tr>
    <td data-label="Listed as">${db.entityById.has(s.target_entity) ? html`<a href="#/entity/${encodeURIComponent(s.target_entity)}">${s.name_as_listed || s.target_entity}</a>` : s.name_as_listed}</td>
    <td data-label="Authority" class="nowrap">${s.authority}</td><td data-label="Program">${s.program || '—'}</td><td data-label="Date" class="nowrap mono">${fmtDate(s.date)}</td>
    <td data-label="Stated reason">${s.reason || html`<span class="empty">Insufficient verified information.</span>`} ${cites(s.source_ids)}</td>
    <td data-label="Official source">${s.official_url ? html`<a href="${s.official_url}" target="_blank" rel="noopener noreferrer">Official notice<span class="visually-hidden"> for ${s.name_as_listed} (opens in new tab)</span></a>` : html`<span class="empty">Not recorded</span>`}</td></tr>`)}</tbody></table></div>`;
}

export function relationshipTable(rels, { perspective = null, caption = 'Relationships' } = {}) {
  if (!rels.length) return empty();
  const rows = [...rels].sort((a, b) => confRank(a.confidence) - confRank(b.confidence));
  return html`<div class="table-wrap cards"><table class="data responsive"><caption>${caption} (${rels.length})</caption>
  <thead><tr><th scope="col">From</th><th scope="col">Relationship</th><th scope="col">To</th><th scope="col">Period</th><th scope="col">Evidence</th></tr></thead>
  <tbody>${rows.map((r) => html`<tr>
    <td data-label="From">${r.from === perspective ? html`<strong>${db.entityById.get(r.from)?.name || r.from}</strong>` : entityLink(r.from)}</td>
    <td data-label="Relationship"><span class="tag">${REL_LABEL[r.type] || r.type}</span>${r.description ? html`<div class="card-meta">${r.description}</div>` : ''}</td>
    <td data-label="To">${r.to === perspective ? html`<strong>${db.entityById.get(r.to)?.name || r.to}</strong>` : entityLink(r.to)}</td>
    <td data-label="Period" class="nowrap">${r.period || '—'}</td>
    <td data-label="Evidence">${badge(r.confidence)} ${cites(r.source_ids)}</td></tr>`)}</tbody></table></div>`;
}

export function timelineList(items, { showCountry = true, idPrefix = 'tl' } = {}) {
  if (!items.length) return empty();
  const sorted = [...items].sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
  const byYear = new Map();
  for (const t of sorted) { const y = String(t.date || '').slice(0, 4) || 'Undated'; if (!byYear.has(y)) byYear.set(y, []); byYear.get(y).push(t); }
  return [...byYear].map(([y, list]) => html`<h3 class="tl-year" id="${idPrefix}-y-${y}">${y}</h3><ol class="tl-list">${list.map((t) => html`<li class="tl-item" ${t.id ? raw(`id="${esc(idPrefix + '-' + t.id)}"`) : ''} data-date="${t.date || ''}">
    <div class="tl-date">${fmtDate(t.date)}</div>
    ${t.title ? html`<h4 class="h3">${t.title}</h4>` : ''}
    <div class="tl-text">${t.text || ''} ${cites(t.source_ids)}</div>
    <div class="tl-meta">${badge(t.confidence)}${t.category ? html`<span class="tag">${TL_CAT_LABEL[t.category] || t.category}</span>` : ''}${showCountry && t.country ? html`<span>${countryLink(t.country)}</span>` : ''}${t.id ? html`<a class="report-link" href="#/corrections?item=${encodeURIComponent(t.id)}">Report an error</a>` : ''}</div>
  </li>`)}</ol>`);
}

export function sourceIdsOf(obj, acc = new Set()) {
  if (!obj || typeof obj !== 'object') return acc;
  if (Array.isArray(obj)) { obj.forEach((o) => sourceIdsOf(o, acc)); return acc; }
  for (const [k, v] of Object.entries(obj)) {
    if (/source_ids$/.test(k) && Array.isArray(v)) v.forEach((s) => acc.add(s));
    else if (v && typeof v === 'object') sourceIdsOf(v, acc);
  }
  return acc;
}
export function sourceListing(ids, { collapse = true } = {}) {
  const list = [...ids].map((id) => [id, db.sourceById.get(id)]);
  if (!list.length) return empty();
  if (collapse && list.length > 12) return html`<details class="group"><summary><span>Show all ${list.length} sources</span><span class="count">${list.length}</span></summary><div class="group-body">${sourceListing(ids, { collapse: false })}</div></details>`;
  return html`<ul class="src-list">${list.map(([id, s]) => (s ? html`<li class="src-item"><a class="src-title" href="#/source/${encodeURIComponent(id)}">${s.title}</a><div class="src-meta">${s.publisher || ''}${s.date ? ' · ' + fmtDate(s.date) : ''} · ${s.category || ''}${s.primary ? ' · primary' : ''}</div></li>` : html`<li class="src-item mono">${id} (missing)</li>`))}</ul>`;
}
export { isEmpty };

// corrections that name a given record (public corrections log entries)
export function correctionsFor(id, { heading = 'Corrections to this record' } = {}) {
  const list = (db.correctionsByItem.get(id) || []).slice().sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
  if (!list.length) return '';
  return html`<section class="section" aria-labelledby="corr-${id}"><h2 id="corr-${id}">${heading} (${list.length})</h2><ul class="src-list">${list.map((c) => correctionItem(c))}</ul><p class="help"><a href="#/corrections">Full corrections log</a></p></section>`;
}
export function correctionItem(c) {
  const same = !c.summary || !c.correction || c.summary.trim() === c.correction.trim();
  return html`<li class="src-item"><div class="src-meta"><span class="mono">${fmtDate(c.date)}</span>${c.type ? html` · <span class="tag">${c.type}</span>` : ''}</div>
    <div>${c.summary ? html`<strong>${c.summary}</strong>` : ''}${!same ? html` ${c.correction}` : !c.summary ? c.correction || '' : ''}</div>
    ${c.before || c.after ? html`<div class="corr-diff"><span class="visually-hidden">Before: </span><del>${c.before || '—'}</del> <span aria-hidden="true">→</span> <span class="visually-hidden">After: </span><ins>${c.after || '—'}</ins></div>` : ''}
    ${(c.source_ids || []).length ? html`<div class="src-meta">Sources: ${cites(c.source_ids)}</div>` : ''}</li>`;
}
