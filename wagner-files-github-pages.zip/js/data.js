// Loads the generated data bundle and builds lookup indices.
// Production: data/bundle.json. Dev fixtures (FAKE): data-dev/bundle.json, only
// when the page is opened on localhost with ?fixtures in the query string.
export let db = null;

const LOCAL_HOSTS = ['localhost', '127.0.0.1', '[::1]', '::1'];
export function usingFixtures() {
  return new URLSearchParams(location.search).has('fixtures') && LOCAL_HOSTS.includes(location.hostname);
}

export function streamOf(file = '') {
  if (/-(ukraine|origins)\.json$/.test(file)) return 'U';
  if (/-(africa|money|sanctions|infoops)\.json$/.test(file)) return 'A';
  return null;
}

const group = (list, keyFn) => {
  const m = new Map();
  for (const r of list) for (const k of [].concat(keyFn(r) ?? [])) { if (k == null) continue; if (!m.has(k)) m.set(k, []); m.get(k).push(r); }
  return m;
};

export async function loadData() {
  const url = usingFixtures() ? 'data-dev/bundle.json' : 'data/bundle.json';
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`Could not load ${url} (HTTP ${res.status}). Run "npm run build" in the site folder.`);
  const b = await res.json();
  const byId = (list, k = 'id') => new Map(list.map((r) => [r[k], r]));
  db = {
    ...b,
    sourceById: byId(b.sources),
    incidentById: byId(b.incidents),
    entityById: byId(b.entities),
    relById: byId(b.relationships),
    sanctionById: byId(b.sanctions),
    countryByIso: byId(b.countries, 'iso3'),
    timelineById: byId(b.timeline),
    pageById: byId(b.pages),
    unprovenById: byId(b.unproven),
    incidentsByCountry: group(b.incidents, (r) => r.country),
    incidentsByEntity: group(b.incidents, (r) => r.alleged_entities || []),
    sanctionsByEntity: group(b.sanctions, (r) => r.target_entity),
    sanctionsByRelatedOrg: group(b.sanctions, (r) => r.related_org || []),
    relsByEntity: group(b.relationships, (r) => [r.from, r.to]),
    membersByOrg: group(b.entities, (r) => r.organizations || []),
    pagesBySection: group(b.pages, (r) => r.section),
    timelineByCountry: group(b.timeline, (r) => r.country),
    correctionsByItem: group(b.corrections, (r) => r.item_id),
  };
  return db;
}

export const countryName = (iso) => db.countryByIso.get(iso)?.name || db.isoNames?.[iso] || iso || '';
export const entityName = (id) => db.entityById.get(id)?.name || id;
export const yearOf = (d) => (typeof d === 'string' ? d.slice(0, 4) : '');
export const pagesFor = (section, stream) => (db.pagesBySection.get(section) || []).filter((p) => !stream || streamOf(p._file) !== (stream === 'U' ? 'A' : 'U'));
