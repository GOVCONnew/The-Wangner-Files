// Accessible side panel (modal dialog): focus trap, Esc to close, focus restore.
import { html, raw } from './lib/html.js';
import { db } from './data.js';
import { fmtDate, SRC_CAT, reportLink } from './ui.js';

let lastFocus = null;
let open = false;

export function closePanel() {
  const root = document.getElementById('panel-root');
  if (!open) return;
  root.innerHTML = '';
  open = false;
  document.removeEventListener('keydown', onKey, true);
  if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
}
function onKey(e) {
  if (e.key === 'Escape') { e.preventDefault(); closePanel(); return; }
  if (e.key === 'Tab') {
    const panel = document.querySelector('#panel-root .panel');
    const f = [...panel.querySelectorAll('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])')];
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
}
export function openPanel({ kicker = '', title, body }) {
  const root = document.getElementById('panel-root');
  if (!open) lastFocus = document.activeElement;
  root.innerHTML = String(html`<div class="panel-overlay" data-close-panel></div>
  <div class="panel" role="dialog" aria-modal="true" aria-labelledby="panel-title">
    <div class="panel-head"><div><p class="kicker">${kicker}</p><h2 id="panel-title">${title}</h2></div>
    <button type="button" class="btn btn-quiet btn-small" data-close-panel aria-label="Close panel">Close ✕</button></div>
    <div class="panel-body">${body}</div>
  </div>`);
  open = true;
  document.addEventListener('keydown', onKey, true);
  root.querySelectorAll('[data-close-panel]').forEach((el) => el.addEventListener('click', closePanel));
  root.querySelector('.panel-body a, .panel-body button, [data-close-panel].btn')?.focus();
  root.querySelector('.panel .btn[data-close-panel]').focus();
}

export function openSource(id) {
  const s = db.sourceById.get(id);
  if (!s) {
    openPanel({ kicker: 'Source', title: 'Missing source reference', body: html`<p>The record cites <code>${id}</code>, which does not exist in the source library. This is a data error.</p><p>${reportLink(id)}</p>` });
    return;
  }
  const row = (k, v) => html`<dt>${k}</dt><dd>${v || html`<span class="empty">Insufficient verified information.</span>`}</dd>`;
  const url = s.url ? html`<a href="${s.url}" target="_blank" rel="noopener noreferrer">${s.url}</a>` : '';
  const arch = s.archive_url ? html`<a href="${s.archive_url}" target="_blank" rel="noopener noreferrer">${s.archive_url}</a>` : html`<span class="muted">No archived copy recorded</span>`;
  openPanel({
    kicker: `Source · ${SRC_CAT[s.category] || s.category || 'uncategorised'}${s.primary === true ? ' · primary' : s.primary === false ? ' · secondary' : ''}`,
    title: s.title || id,
    body: html`<dl class="fields">
      ${row('Source', s.title)}
      ${row('Publication', s.publisher)}
      ${s.author ? row('Author', s.author) : ''}
      ${row('Date', fmtDate(s.date))}
      ${row('URL', url)}
      ${row('Archived URL', arch)}
      ${row('Relevant evidence', s.key_evidence)}
      ${row('Summary', s.summary)}
      ${row('Access date', fmtDate(s.access_date))}
    </dl>
    ${s.category === 'party-statement' ? html`<p class="note-box">Party statement: this records what a party to the conflict claimed. It is not independent verification.</p>` : ''}
    <div class="panel-actions"><a class="btn" href="#/source/${encodeURIComponent(id)}">Open library page →</a>${reportLink(id)}</div>`,
  });
}
export const isPanelOpen = () => open;
export { raw };
