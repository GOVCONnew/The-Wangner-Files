// Leaflet world map rendered from local Natural Earth geometry (no tile server).
import { html, badge, incidentTitle, STATUS, fmtDate } from './ui.js';
import { db, countryName } from './data.js';

let Lp = null, geoP = null;
const STATUS_COLOR = { 'active-africa-corps': '#d2463c', 'active-wagner-legacy': '#e0894a', reported: '#bfae6b', former: '#6b8799', insufficient: '#5a5e65' };
export { CONF_COLOR } from './confcolors.js';
import { CONF_COLOR } from './confcolors.js';

function loadLeaflet() {
  if (!document.querySelector('link[data-leaflet]')) {
    const l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = 'vendor/leaflet/leaflet.css'; l.dataset.leaflet = '1';
    document.head.appendChild(l);
  }
  Lp ||= import('../vendor/leaflet/leaflet-src.esm.js');
  return Lp;
}
const loadGeo = () => (geoP ||= fetch('assets/geo/world-50m.json').then((r) => r.json()));

export async function createMap(el, { bounds = null, onCountry, incidents = [], showIncidents = false, region = null } = {}) {
  const [L, geo] = await Promise.all([loadLeaflet(), loadGeo()]);
  const map = L.map(el, { zoomSnap: 0.25, minZoom: 1, maxZoom: 8, worldCopyJump: false, maxBounds: [[-85, -200], [85, 200]], attributionControl: true, zoomControl: true, keyboard: true });
  map.attributionControl.setPrefix(false);
  map.attributionControl.addAttribution('Geometry: Natural Earth · <a href="https://leafletjs.com" target="_blank" rel="noopener noreferrer">Leaflet</a>');
  const layer = L.geoJSON(geo, {
    style: (f) => {
      const c = db.countryByIso.get(f.properties.iso3);
      return { color: c ? '#0b1117' : '#2a2e33', weight: c ? 0.8 : 0.5, fillColor: c ? STATUS_COLOR[c.status] || STATUS_COLOR.insufficient : '#202327', fillOpacity: c ? 0.92 : 1, dashArray: c?.status === 'insufficient' ? '2 2' : null };
    },
    onEachFeature: (f, lyr) => {
      const iso = f.properties.iso3;
      const c = db.countryByIso.get(iso);
      lyr.bindTooltip(c ? `${c.name} — ${STATUS[c.status]?.label || c.status}` : `${f.properties.name} — not in database`, { sticky: true, direction: 'top' });
      if (c) {
        lyr.on('click', () => onCountry?.(iso));
        lyr.on('mouseover', () => lyr.setStyle({ weight: 2, color: '#f3d27a' }));
        lyr.on('mouseout', () => layer.resetStyle(lyr));
      }
    },
  }).addTo(map);
  const markers = L.layerGroup();
  for (const i of incidents) {
    if (typeof i.lat !== 'number' || typeof i.lon !== 'number') continue;
    const m = L.circleMarker([i.lat, i.lon], { radius: 5, color: '#0b0c0e', weight: 1, fillColor: CONF_COLOR[i.confidence] || '#a9aeb5', fillOpacity: 0.95 });
    m.bindPopup(String(html`<div style="min-width:200px"><div style="margin-bottom:.3rem">${badge(i.confidence)}</div><a href="#/incident/${encodeURIComponent(i.id)}"><strong>${incidentTitle(i)}</strong></a><div style="font-size:.8rem;margin-top:.2rem">${fmtDate(i.date)} · ${i.location || ''}${i.location ? ', ' : ''}${countryName(i.country)}</div></div>`));
    m.on('add', () => m.getElement()?.setAttribute('data-incident', i.id));
    markers.addLayer(m);
  }
  if (showIncidents) markers.addTo(map);
  if (!bounds) {
    // fit to the countries present in the database (fallback: whole world)
    let b = null;
    layer.eachLayer((lyr) => { if (db.countryByIso.has(lyr.feature.properties.iso3)) { const lb = lyr.getBounds(); b = b ? b.extend(lb) : L.latLngBounds(lb.getSouthWest(), lb.getNorthEast()); } });
    bounds = b ? b.pad(0.25) : [[-50, -170], [78, 180]];
  }
  map.fitBounds(bounds, { maxZoom: 4 });
  // (after the view is set, so paths exist) mark country paths for testing / assistive tech hints
  layer.eachLayer((lyr) => { const iso = lyr.feature.properties.iso3; const p = lyr.getElement?.(); if (p) { p.setAttribute('data-iso3', iso); if (db.countryByIso.has(iso)) p.classList.add('in-db'); } });

  const ro = new ResizeObserver(() => map.invalidateSize());
  ro.observe(el);
  return {
    map, L,
    setIncidents(on) { if (on) markers.addTo(map); else markers.remove(); },
    destroy() { ro.disconnect(); map.remove(); },
  };
}
