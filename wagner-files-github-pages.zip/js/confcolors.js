export const CONF_COLOR = { confirmed: '#5cc873', strong: '#74adff', credible: '#e6c24f', disputed: '#f39150', unverified: '#a9aeb5' };
