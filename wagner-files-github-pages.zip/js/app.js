import { loadData, db, usingFixtures } from './data.js';
import { html } from './lib/html.js';
import { startCitations, endnotes, fmtDate } from './ui.js';
import { openSource, closePanel } from './panel.js';

const ROUTES = {
  '': 'home', map: 'map', country: 'country', ukraine: 'ukraine', africa: 'africa', incidents: 'incidents', incident: 'incident',
  network: 'network', money: 'money', sanctions: 'sanctions', people: 'people', entity: 'entity', timeline: 'timeline',
  library: 'library', source: 'source', findings: 'findings', summary: 'summary', methodology: 'methodology',
  corrections: 'corrections', search: 'search', section: 'section',
};
const NAV_FOR = { country: 'map', incident: 'incidents', entity: 'people', source: 'library', section: 'home' };
const main = document.getElementById('main');
let current = null; // mounted view module
let renderToken = 0;

export function parseHash() {
  const h = location.hash.replace(/^#\/?/, '');
  const [pathPart, queryPart = ''] = h.split('?');
  const segs = pathPart.split('/').filter(Boolean).map(decodeURIComponent);
  return { name: segs[0] || '', params: segs.slice(1), query: new URLSearchParams(queryPart), raw: h };
}

async function route({ focus = true } = {}) {
  const hash = location.hash;
  if (hash && !hash.startsWith('#/') && hash !== '#') return; // in-page anchor (e.g. skip link)
  const token = ++renderToken;
  const r = parseHash();
  const viewName = ROUTES[r.name];
  closePanel();
  if (current?.unmount) { try { current.unmount(); } catch (e) { console.warn(e); } }
  current = null;
  document.querySelectorAll('#primary-nav a').forEach((a) => a.removeAttribute('aria-current'));
  const navKey = NAV_FOR[r.name] || r.name || 'home';
  document.querySelector(`#primary-nav a[data-nav="${navKey}"]`)?.setAttribute('aria-current', 'page');
  document.getElementById('primary-nav').classList.remove('open');
  document.getElementById('menu-toggle').setAttribute('aria-expanded', 'false');

  delete main.dataset.rendered;
  if (!viewName) { renderNotFound(); main.dataset.rendered = r.raw; return; }
  let mod;
  try { mod = await import(`./views/${viewName}.js`); } catch (e) { console.error(e); renderError(e); return; }
  if (token !== renderToken) return;
  startCitations();
  const ctx = { db, params: r.params, query: r.query, name: r.name };
  let out;
  try { out = await mod.render(ctx); } catch (e) { console.error(e); renderError(e); return; }
  if (token !== renderToken) return;
  if (!out) { renderNotFound(); return; }
  main.innerHTML = `<div class="page container">${out.html}</div>${endnotes()}`;
  document.title = `${out.title ? out.title + ' — ' : ''}THE WAGNER FILES${usingFixtures() ? ' [FIXTURES]' : ''}`;
  current = mod;
  if (mod.mount) { try { await mod.mount(main, ctx); } catch (e) { console.error(e); } }
  main.dataset.rendered = r.raw || '/';
  if (focus) {
    window.scrollTo(0, 0);
    const h1 = main.querySelector('h1');
    (h1 || main).focus({ preventScroll: true });
  }
}
// re-render the current view's endnotes after a view updates its own content
export function refreshEndnotes() {
  main.querySelector('.endnotes')?.remove();
  main.insertAdjacentHTML('beforeend', String(endnotes()));
}

function renderNotFound() {
  main.innerHTML = String(html`<div class="page container"><header class="page-head"><p class="kicker">Not found</p><h1 tabindex="-1">Page not found</h1><p class="lede">This address does not match any page or record in the database. The record may have been renamed or removed.</p></header><p><a href="#/">Return to the home page</a> · <a href="#/search">Search the database</a></p></div>`);
  document.title = 'Not found — THE WAGNER FILES';
  main.querySelector('h1').focus();
}
function renderError(e) {
  main.innerHTML = String(html`<div class="page container"><div class="error-box" role="alert"><h1 tabindex="-1">Something went wrong</h1><p>${e.message || String(e)}</p></div></div>`);
}

function initChrome() {
  document.getElementById('menu-toggle').addEventListener('click', (e) => {
    const nav = document.getElementById('primary-nav');
    const open = nav.classList.toggle('open');
    e.currentTarget.setAttribute('aria-expanded', String(open));
  });
  document.getElementById('header-search').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = e.currentTarget.q.value.trim();
    location.hash = `#/search${q ? '?q=' + encodeURIComponent(q) : ''}`;
  });
  document.querySelector('[data-skip]').addEventListener('click', (e) => {
    e.preventDefault();
    const h1 = main.querySelector('h1');
    (h1 || main).focus();
    (h1 || main).scrollIntoView();
  });
  // global delegation: citation markers + in-page scroll links
  document.addEventListener('click', (e) => {
    const c = e.target.closest('[data-src]');
    if (c && (c.classList.contains('cite') || c.hasAttribute('data-open-source'))) { e.preventDefault(); openSource(c.getAttribute('data-src')); return; }
    const s = e.target.closest('a[data-scroll-to]');
    if (s) {
      const el = document.getElementById(s.getAttribute('data-scroll-to'));
      if (el) { e.preventDefault(); el.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); const h = el.matches('h2,h3') ? el : el.querySelector('h2,h3'); if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); } }
    }
  });
}

async function boot() {
  initChrome();
  if (usingFixtures()) document.getElementById('fixture-banner').hidden = false;
  try {
    await loadData();
  } catch (e) {
    main.innerHTML = String(html`<div class="page container"><div class="error-box" role="alert"><h1>Data bundle unavailable</h1><p>${e.message}</p></div></div>`);
    return;
  }
  if (db.meta?.fixtures) document.getElementById('fixture-banner').hidden = false;
  document.getElementById('footer-updated').textContent = `Last updated ${fmtDate(db.meta.last_updated)}`;
  window.addEventListener('hashchange', () => route());
  await route({ focus: false });
  document.documentElement.dataset.ready = 'true';
}
boot();
