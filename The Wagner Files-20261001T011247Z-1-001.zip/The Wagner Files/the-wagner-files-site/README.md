# THE WAGNER FILES — website (presentation layer)

A static, dependency-free web app (vanilla ES modules) that renders **only** the JSON research data in
`/workspace/wagner-files/data/`. It contains no research content of its own. Libraries (Leaflet, D3, MiniSearch),
fonts (Inter, Source Serif 4, IBM Plex Mono) and map geometry (Natural Earth 1:50m) are vendored locally, so the page
makes no third-party requests at runtime.

## Quick start

```bash
cd /workspace/wagner-files/site
npm run build            # merge + validate ../data  -> data/bundle.json (prints the broken-reference report)
npm run serve            # http://127.0.0.1:8787/   (PORT=… HOST=… to change)
```

Node 18+ is the only requirement for building/serving. `npm install` is only needed for the test tooling
(Playwright, axe-core) and to re-vendor libraries.

| Command | What it does |
|---|---|
| `npm run build` | Build the production bundle from `../data` → `data/bundle.json` + `data/validation-report.json` |
| `npm run build:strict` | Same, but exits 1 if any ERROR is found (use in CI) |
| `node scripts/build-data.mjs --verbose` | Print every warning/info line instead of the first 40/15 |
| `npm run fixtures:generate` | Regenerate the FAKE dev fixture set in `../dev-fixtures/` |
| `npm run build:fixtures` | Build the FAKE fixtures → `data-dev/bundle.json` (never `data/`) |
| `npm run serve` | Static server with gzip on 127.0.0.1:8787 |
| `npm run watch` | Rebuild `data/bundle.json` automatically whenever `../data` changes (debounced 2 s) |
| `npm test` | Playwright + axe end-to-end verification: fixture suite (`tests/verify.mjs`) then real-data suite (`tests/verify-real.mjs`). Server must be running; fixtures and real data built |
| `npm run test:real` | Real-data suite only: every route at 1440/390 px, every country, incident, profile, a sample of sources; evidence-integrity scan (badge + source markers on every claim/finding/event/incident row, “Alleged” framing); map→country for all countries; axe. Screenshots → `../screenshots/final/` |
| `npm run test:validator` | Unit test for the validator (deliberately broken temp data set) |
| `npm run dist` | Copy a deployable site to `../site-dist/` (excludes fixtures, tests, scripts; refuses a fixture bundle) |
| `npm run vendor` | Re-copy vendored libraries/fonts and rebuild the world geometry from Natural Earth |

### Dev fixtures (fake data) — the switch

`../dev-fixtures/` holds an obviously fake data set ("Example Incident A", `example.org` URLs, "Example Country B"…)
for layout and scale testing (1,200 sources, 320 incidents). It is built to a **separate** directory, `data-dev/`,
and is only loaded when the page is opened **on localhost with `?fixtures`** in the URL:

    http://127.0.0.1:8787/?fixtures=1#/incidents

Every page then shows a red "DEVELOPMENT FIXTURES — FAKE" banner. The default is always the real `data/bundle.json`;
`npm run dist` never copies `data-dev/` and refuses to ship if `data/bundle.json` was built from fixtures; the
validator flags any `example.org` URL found in real data (`fixture-leak`).

## Deploying

The site is plain static files. Run `npm run build && npm run dist` and upload `../site-dist/` to any static host
(GitHub Pages, Netlify, S3, nginx). Routing uses the URL hash (`#/incident/inc-ua-…`), so no server rewrites are needed.

## Adding or updating data

All research lives in `/workspace/wagner-files/data/<collection>/*.json`; each file is a JSON **array** of records and
every file in a collection directory is merged. Follow `/workspace/wagner-files/SCHEMA.md` exactly. After any edit:

```bash
npm run build     # read the VALIDATION section and fix every ERROR
```

Then reload the browser (the server sends `no-cache`).

**Add a source** — `data/sources/sources-<stream>.json`:
```json
{ "id": "src-a-…", "title": "…", "publisher": "…", "date": "2024-05-01", "url": "https://…",
  "archive_url": "https://web.archive.org/…", "access_date": "2026-09-30", "category": "ngo",
  "primary": true, "summary": "…", "key_evidence": "…" }
```
Only URLs that were actually opened. `category` must be one of `un government sanctions court ngo journalism academic osint party-statement`.

**Add an incident** — `data/incidents/incidents-<stream>.json` (id `inc-ua-…` or `inc-af-…`). Required: `id, date,
country (ISO3), title, description, types[], confidence, source_ids[≥1]`. `lat`/`lon` (numbers or null) place a map
marker. Every other field in SCHEMA.md is displayed; a missing one shows "Insufficient verified information."
Non-`confirmed` incidents are automatically presented as allegations ("Alleged: …").

**Add an entity** — `data/entities/entities-<stream>.json` (public figures and organizations only). `kind` drives the
network tier (see below). `activities` is an array of claim objects `{text, confidence, source_ids, note?}`.

**Add a relationship** — `data/relationships/…`: `from`/`to` must be existing entity ids; at least one source is required.

**Add a sanction** — `data/sanctions/sanctions-sanctions.json`: `target_entity` must exist in entities (create it first);
`authority` ∈ `US-OFAC US-State EU UK CA AU UN CH JP NZ UA other`; give `official_url`.

**Add a country** — `data/countries/countries-<stream>.json`: `iso3` (3 uppercase letters, must exist in
`config/iso3-names.json` to appear on the map), `status` ∈ `active-africa-corps active-wagner-legacy former reported
insufficient`, claim arrays for each section (use `[]` when nothing is verified). The country appears automatically on
the map, the Africa page (if `region` is `Africa`) and gets its own page at `#/country/ISO3`.

**Timeline / pages / findings / unproven** — as in SCHEMA.md. `data/findings/candidates-*.json` are research candidate
lists and are **excluded** from the published Findings page; the compiled list goes in any other file in `data/findings/`.

**Corrections log** — `data/corrections/corrections.json` (site-defined format, optional):
```json
{ "id": "cor-2026-10-01-1", "date": "2026-10-01", "item_id": "inc-af-…", "summary": "Date corrected",
  "correction": "The incident date was changed from … to … based on …", "source_ids": ["src-a-…"] }
```

### What the validator checks

JSON syntax; every file is an array; required fields; enum values (confidence, categories, incident types, entity kinds,
relationship types, authorities, statuses, sections, timeline categories); date formats; http(s) URLs; id prefixes and
uniqueness across files; **referential integrity** — every `source_ids` entry (including inside claims and page tables),
every entity reference (`alleged_entities`, `organizations`, relationship `from`/`to`, `target_entity`, `related_org`,
`entities_present`, `companies`); relationships without sources; ISO3 codes not on the map; example/fixture URLs in real
data; plus informational notes (uncited sources, unlinked entities, files not matching a stream suffix). The full list is
written to `data/validation-report.json`. Broken references never crash the site: a missing source renders as `[n?]`
and a missing entity as `ent-… (missing)`.

## Configuration

* `config/site.config.json` — title/subtitle, `last_updated` override (otherwise the bundle build date), and the
  corrections destination. **`corrections.email` and `corrections.github_repo` are PLACEHOLDERS**
  (`corrections@example.invalid`, `OWNER/REPO`); replace them and set `PLACEHOLDER: false` before publishing.
* `config/tiers.json` — network tiers. Resolution order: `overrides` by entity id → `keyword_rules` (regex on name+role
  per kind) → `kind_defaults`. A data-side `data/tiers-overrides.json` (`{"ent-…": 5}`) is also honoured.
* `config/eras.json` — era buttons on the Timeline page (navigation anchors only, not claims).
* `config/iso3-names.json` — generated from the map geometry.

## File structure

```
site/
  index.html              app shell (header, nav, skip link, footer, panel root)
  assets/css/             main.css (theme), fonts.css (@font-face)
  assets/fonts/           self-hosted woff2 + licences
  assets/geo/world-50m.json  Natural Earth 1:50m countries (iso3, name), lazy-loaded by map views
  vendor/                 leaflet/, d3/, minisearch/ (with licences)
  config/                 site.config.json, tiers.json, eras.json, iso3-names.json
  js/app.js               boot + hash router + global handlers
  js/data.js              bundle loader, indices, fixture switch
  js/ui.js                badges, claims, citations/endnotes, tables, helpers
  js/panel.js             accessible side-panel dialog + source panel
  js/components.js        shared tables/timeline/source lists
  js/mapkit.js            Leaflet world map (lazy)
  js/graphkit.js          D3 tiered force graph (lazy)
  js/netpanels.js         node/edge evidence panels
  js/views/*.js           one module per page (lazy-loaded)
  scripts/build-data.mjs  merge + validate + backlinks → data/bundle.json
  scripts/make-fixtures.mjs  FAKE fixture generator → ../dev-fixtures
  scripts/serve.mjs       static server        scripts/dist.mjs  deployable copy
  scripts/watch-data.mjs  auto-rebuild on data changes
  scripts/vendor.mjs      vendoring + geometry build
  tests/verify.mjs        Playwright + axe E2E (fixtures)   tests/verify-real.mjs  E2E on real data
  tests/validator.test.mjs  validator unit test
  data/                   GENERATED production bundle (from ../data)
  data-dev/               GENERATED fixture bundle (gitignored, never shipped)
```

## Routes (all shareable)

`#/` home · `#/summary` · `#/map` · `#/country/MLI` · `#/ukraine` · `#/africa` · `#/incidents?country=&year=&type=&org=&conf=&q=` ·
`#/incident/<id>` · `#/network?country=&kind=&type=&conf=&focus=<ent-id>&view=list` · `#/money?sector=gold` ·
`#/sanctions?authority=&year=&kind=&org=&q=` · `#/people?kind=&country=&q=` · `#/entity/<id>` · `#/timeline?cat=&country=&conf=&focus=<tl-id>` ·
`#/library?q=&cat=&primary=` · `#/source/<id>` · `#/findings` · `#/methodology` · `#/corrections?item=<id>` · `#/search?q=` · `#/section/<section>`

## Accessibility & design notes

Semantic landmarks, skip link, focus management on navigation, visible focus states, ARIA modal side panel with focus
trap/Escape/focus restore, evidence badges always carry text labels (never colour alone) and meet WCAG AA contrast on
the dark background, list alternatives for the map (country list) and graph (list view + keyboard-focusable nodes),
tables turn into labelled cards on small screens, `prefers-reduced-motion` respected (graph layout is precomputed; no
continuous animation). Verified with axe-core (see `tests/results/verify-report.json`).

## Data pipeline note

The research-stage Python generator (`work-u/py/build.py`) has been renamed `build.py.DISABLED`: re-running it would regenerate
`data/*.json` and overwrite the editorial corrections recorded in `data/corrections/corrections-editorial.json`. Edit `data/` directly
and run `npm run build:strict`.

Entity kinds `aircraft` and `vessel` were added (validator `ENT_KIND`, `js/ui.js` labels, `config/tiers.json` defaults → Logistics tier).
`SCHEMA.md` does not yet list them in the entity `kind` enum.
